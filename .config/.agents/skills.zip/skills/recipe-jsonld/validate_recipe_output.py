#!/usr/bin/env python3
"""Validate a canonical recipe JSON object against the shared schema."""
import json
import sys
import uuid
from pathlib import Path

sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import APPROVED_UNITS

NAMESPACE = uuid.UUID('3c6e7b7e-df8d-4bda-8b5c-5e7b9d2f3a1c')

from recipe_common import APPROVED_UNITS

REQUIRED_FIELDS = [
    '@context', '@type', 'id', 'identifier', 'name', 'url', 'image',
    'recipeCategory', 'recipeIngredient', 'recipeInstructions'
]

OPTIONAL_FIELDS = [
    'author', 'datePublished', 'dateModified', 'description',
    'prepTime', 'cookTime', 'totalTime', 'recipeYield',
    'recipeCuisine', 'keywords',
    'nutrition', 'aggregateRating', 'suitableForDiet', 'video', '@id'
]


def validate(obj):
    errors = []

    for f in REQUIRED_FIELDS:
        if f not in obj:
            errors.append(f'missing required field: {f}')

    if obj.get('@context') != 'https://schema.org':
        errors.append(f"@context should be 'https://schema.org', got {obj.get('@context')}")

    if obj.get('@type') != 'Recipe':
        errors.append(f"@type should be 'Recipe', got {obj.get('@type')}")

    if not obj.get('image'):
        errors.append('image is empty')

    if not isinstance(obj.get('recipeCategory'), list):
        errors.append('recipeCategory must be an array')

    if not isinstance(obj.get('recipeIngredient'), list):
        errors.append('recipeIngredient must be an array')
    else:
        for i, ing in enumerate(obj['recipeIngredient']):
            for k in ['name', 'quantity', 'unit', 'note']:
                if k not in ing:
                    errors.append(f'ingredient {i} missing {k}')
            if ing.get('quantity') is not None and not isinstance(ing.get('quantity'), (int, float)):
                errors.append(f'ingredient {i} quantity must be a number or null, got {type(ing.get("quantity")).__name__}')
            if ing.get('unit') and ing.get('unit') not in APPROVED_UNITS:
                errors.append(f'ingredient {i} unit "{ing.get("unit")}" is not in the approved unit list')
            if not isinstance(ing.get('unit'), str):
                errors.append(f'ingredient {i} unit must be a string')
            if not isinstance(ing.get('note'), str):
                errors.append(f'ingredient {i} note must be a string')

    if not isinstance(obj.get('recipeInstructions'), list):
        errors.append('recipeInstructions must be an array')
    else:
        for i, step in enumerate(obj['recipeInstructions']):
            if step.get('@type') != 'HowToStep':
                errors.append(f'instruction {i} @type should be HowToStep')
            for k in ['text', 'name', 'image', 'url']:
                if k not in step:
                    errors.append(f'instruction {i} missing {k}')

    # verify deterministic id
    identifier = obj.get('identifier', '')
    expected_id = str(uuid.uuid5(NAMESPACE, identifier))
    if obj.get('id') != expected_id:
        errors.append(f"id {obj.get('id')} does not match expected UUIDv5 {expected_id} for identifier {identifier}")

    # check optional fields exist
    for f in OPTIONAL_FIELDS:
        if f not in obj:
            errors.append(f'missing optional field (should be null/empty): {f}')

    array_optional = ['recipeCuisine', 'keywords', 'suitableForDiet']
    for f in array_optional:
        if f in obj and not isinstance(obj[f], list):
            errors.append(f'{f} must be an array')

    return errors


if __name__ == '__main__':
    import sys
    for path in sys.argv[1:]:
        print(f'\n=== {path} ===')
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        errors = validate(data)
        if errors:
            print('ERRORS:')
            for e in errors:
                print(f'  - {e}')
        else:
            print('VALID')
