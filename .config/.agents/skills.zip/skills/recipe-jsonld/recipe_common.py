#!/usr/bin/env python3
"""Shared recipe parsing utilities for validating recipe-* skills."""
import json
import re
import time
import uuid
from typing import Any, List, Optional, Tuple
from urllib.parse import urljoin
from lxml import html
import requests

def fetch_with_retries(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    data: Optional[str] = None,
    retries: int = 3,
    backoff: float = 1.0,
    timeout: float = 20.0,
) -> requests.Response:
    """Make an HTTP request with exponential-backoff retries.

    Retries on network errors and 5xx/429/403 responses (some sites
    intermittently block).  The first attempt is made immediately.
    """
    method = method.upper()
    last_exception: Optional[Exception] = None
    for attempt in range(retries):
        try:
            if method == 'GET':
                r = requests.get(url, headers=headers, timeout=timeout)
            elif method == 'POST':
                r = requests.post(url, headers=headers, data=data, timeout=timeout)
            else:
                raise ValueError(f'Unsupported method {method}')
            if r.status_code < 400:
                return r
            # Retry transient failures and intermittent blocks.
            if r.status_code in (403, 429, 500, 502, 503, 504):
                last_exception = Exception(f'{r.status_code} {r.reason} for url: {url}')
            else:
                r.raise_for_status()
        except requests.RequestException as e:
            last_exception = e
        if attempt < retries - 1:
            time.sleep(backoff * (2 ** attempt))
    if last_exception:
        raise last_exception
    raise requests.RequestException(f'All {retries} attempts failed for {url}')


KITCHENMIX_NAMESPACE = uuid.UUID('3c6e7b7e-df8d-4bda-8b5c-5e7b9d2f3a1c')

# Approved units from KitchenMix web/src/components/ui/IngredientDialog/index.tsx
APPROVED_UNITS = {
    'bag', 'bunch', 'head', 'loaf', 'package', 'piece',
    'ml', 'l', 'tsp', 'tbsp', 'c', 'fl-oz', 'pt', 'qt', 'gal',
    'mg', 'g', 'kg', 'oz', 'lb',
}

# Common synonyms / plurals / abbreviations mapped to canonical approved unit.
# All keys are lowercase; matching is case-insensitive.
UNIT_SYNONYMS = {
    'bag': 'bag', 'bags': 'bag',
    'bunch': 'bunch', 'bunches': 'bunch',
    'head': 'head', 'heads': 'head',
    'loaf': 'loaf', 'loaves': 'loaf', 'loafs': 'loaf',
    'package': 'package', 'packages': 'package', 'pkg': 'package', 'pkgs': 'package',
    'piece': 'piece', 'pieces': 'piece', 'pc': 'piece', 'pcs': 'piece',
    'milliliter': 'ml', 'milliliters': 'ml', 'millilitre': 'ml', 'millilitres': 'ml',
    'ml': 'ml',
    'liter': 'l', 'liters': 'l', 'litre': 'l', 'litres': 'l',
    'l': 'l',
    'teaspoon': 'tsp', 'teaspoons': 'tsp', 'tsp': 'tsp', 'tsps': 'tsp', 't.': 'tsp',
    'tablespoon': 'tbsp', 'tablespoons': 'tbsp', 'tbsp': 'tbsp', 'tbsps': 'tbsp',
    'tbs': 'tbsp', 'tbsp.': 'tbsp', 'tbs.': 'tbsp', 't.': 'tbsp', 't': 'tbsp',
    'cup': 'c', 'cups': 'c',
    'c': 'c',
    'fluid ounce': 'fl-oz', 'fluid ounces': 'fl-oz', 'fl oz': 'fl-oz', 'fl. oz': 'fl-oz',
    'fl.oz': 'fl-oz', 'floz': 'fl-oz',
    'fl-oz': 'fl-oz',
    'pint': 'pt', 'pints': 'pt',
    'pt': 'pt',
    'quart': 'qt', 'quarts': 'qt',
    'qt': 'qt',
    'gallon': 'gal', 'gallons': 'gal',
    'gal': 'gal',
    'milligram': 'mg', 'milligrams': 'mg', 'milligramme': 'mg', 'milligrammes': 'mg',
    'mg': 'mg',
    'gram': 'g', 'grams': 'g', 'gramme': 'g', 'grammes': 'g',
    'g': 'g',
    'kilogram': 'kg', 'kilograms': 'kg', 'kilogramme': 'kg', 'kilogrammes': 'kg',
    'kilo': 'kg', 'kilos': 'kg',
    'kg': 'kg',
    'ounce': 'oz', 'ounces': 'oz',
    'oz': 'oz',
    'pound': 'lb', 'pounds': 'lb', 'lb': 'lb', 'lbs': 'lb', 'lb.': 'lb',
}

UNICODE_FRACTIONS = {
    '½': '1/2', '¼': '1/4', '¾': '3/4', '⅓': '1/3', '⅔': '2/3',
    '⅕': '1/5', '⅖': '2/5', '⅗': '3/5', '⅘': '4/5', '⅙': '1/6',
    '⅚': '5/6', '⅛': '1/8', '⅜': '3/8', '⅝': '5/8', '⅞': '7/8',
    '⅑': '1/9', '⅒': '1/10', '⅟': '1/',
}

# Common mojibake sequences produced when UTF-8 fraction bytes are decoded as
# Latin-1 / Windows-1252.  They are normalised to slash fractions so the same
# fraction parser handles mixed numbers ("1 Â½ cups" -> "1 1/2 cups").
MOJIBAKE_FRACTIONS = {
    'Â¼': '1/4',
    'Â½': '1/2',
    'Â¾': '3/4',
    'â…“': '1/3',
    'â…”': '2/3',
    'â…•': '1/5',
    'â…–': '2/5',
    'â…—': '3/5',
    'â…˜': '4/5',
    'â…™': '1/6',
    'â…š': '5/6',
    'â…›': '1/8',
    'â…œ': '3/8',
    'â…': '5/8',
    'â…ž': '7/8',
    'â…‘': '1/9',
    'â…’': '1/10',
}

WORD_FRACTIONS = {
    'half': 0.5, 'halves': 0.5,
    'quarter': 0.25, 'quarters': 0.25, 'fourth': 0.25, 'fourths': 0.25,
    'third': 1/3, 'thirds': 1/3,
    'fifth': 0.2, 'fifths': 0.2,
    'sixth': 1/6, 'sixths': 1/6,
    'seventh': 1/7, 'sevenths': 1/7,
    'eighth': 0.125, 'eighths': 0.125,
    'ninth': 1/9, 'ninths': 1/9,
    'tenth': 0.1, 'tenths': 0.1,
}


def normalize_unicode_fractions(text: str) -> str:
    # Fix common mojibake sequences first; they can appear adjacent to other text
    # (e.g. "Â¼ cup").  Convert them to slash fractions so mixed numbers parse.
    for seq, replacement in MOJIBAKE_FRACTIONS.items():
        text = text.replace(seq, f" {replacement} ")
    for char, replacement in UNICODE_FRACTIONS.items():
        text = text.replace(char, f" {replacement} ")
    return re.sub(r'\s+', ' ', text).strip()


def parse_quantity(qty_str: str) -> Optional[float]:
    """Convert a quantity string to a float. Returns None if not parseable."""
    s = normalize_unicode_fractions(qty_str).strip().lower()
    if not s:
        return None

    # Pure word fraction
    if s in WORD_FRACTIONS and not re.search(r'\d', s):
        return float(WORD_FRACTIONS[s])

    # Range of two values (integers, decimals, or fractions)
    m = re.match(
        r'^(\d+(?:\.\d+)?(?:\s+\d+/\d+)?)\s*(?:-|–|to)\s*(\d+(?:\.\d+)?(?:\s+\d+/\d+)?)$',
        s
    )
    if m:
        a = parse_quantity(m.group(1))
        b = parse_quantity(m.group(2))
        if a is not None and b is not None:
            return (a + b) / 2.0
        return a if a is not None else b

    # Mixed number: 1 1/2
    m = re.match(r'^(\d+(?:\.\d+)?)\s+(\d+)/(\d+)$', s)
    if m:
        return float(m.group(1)) + float(m.group(2)) / float(m.group(3))

    # Simple fraction: 1/2, 3/4
    m = re.match(r'^(\d+)/(\d+)$', s)
    if m:
        return float(m.group(1)) / float(m.group(2))

    # Plain decimal / integer
    m = re.match(r'^(\d+(?:\.\d+)?)$', s)
    if m:
        return float(m.group(1))

    return None


def canonical_unit(unit_text: str) -> str:
    cleaned = re.sub(r'[^a-z0-9\s-]', '', unit_text.lower())
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return UNIT_SYNONYMS.get(cleaned, '')


# Pre-sort synonyms by length descending so longer phrases match first.
_SORTED_SYNONYMS = sorted(UNIT_SYNONYMS.keys(), key=len, reverse=True)


def find_unit_and_name(remainder: str) -> Tuple[str, str]:
    """Look for a recognized unit at the start of remainder and return (unit, name)."""
    remainder = remainder.strip()
    for synonym in _SORTED_SYNONYMS:
        pattern = r'^' + re.escape(synonym) + r'[\.\s,]*\b(.*)$'
        m = re.match(pattern, remainder, re.IGNORECASE)
        if m:
            return canonical_unit(synonym), m.group(1).strip('., ')
    return '', remainder


def parse_ingredient(text: str) -> dict:
    """Parse a raw ingredient string into {name, quantity, unit, note}."""
    original = text.strip()
    if not original:
        return {'name': '', 'quantity': None, 'unit': '', 'note': ''}

    # Extract all parenthetical notes, then remove them from the working text.
    notes = []
    working = original
    while True:
        start = working.find('(')
        if start == -1:
            break
        end = working.find(')', start)
        if end == -1:
            break
        notes.append(working[start + 1:end].strip())
        working = (working[:start].strip() + ' ' + working[end + 1:].strip()).strip()
    note = '; '.join(notes)

    working = normalize_unicode_fractions(working)

    # Word fraction at start, e.g. "half cup" or "half onion"
    m = re.match(r'^\s*(half|quarter|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|halves|quarters|fourths|thirds|fifths|sixths|sevenths|eighths|ninths|tenths)(?:\s+|$)', working, re.IGNORECASE)
    if m:
        word = m.group(1).lower()
        remainder = working[m.end():].strip()
        unit, name = find_unit_and_name(remainder)
        return {
            'name': name,
            'quantity': round(float(WORD_FRACTIONS[word]), 4),
            'unit': unit,
            'note': note,
        }

    # Numeric quantity at start: supports integers, decimals, fractions, mixed
    # numbers, and ranges (1-2, 1 to 2, 1/2-3/4).
    qty_pattern = (
        r'(?:(?:\d+(?:\.\d+)?\s+)?\d+/\d+|\d+(?:\.\d+)?)'
        r'(?:\s*(?:-|–|to)\s*(?:(?:\d+(?:\.\d+)?\s+)?\d+/\d+|\d+(?:\.\d+)?))?'
    )
    m = re.match(r'^\s*(' + qty_pattern + r')\s*(.*)$', working)
    if m:
        qty_str = m.group(1).strip()
        remainder = m.group(2).strip()
        unit, name = find_unit_and_name(remainder)
        qty = parse_quantity(qty_str)
        if qty is not None:
            qty = round(qty, 4)
        return {
            'name': name,
            'quantity': qty,
            'unit': unit,
            'note': note,
        }

    # Unparseable: preserve full original text
    return {'name': original, 'quantity': None, 'unit': '', 'note': note}


def slugify(text: str) -> str:
    text = text.lower()
    text = re.sub(r'[^a-z0-9]+', '-', text)
    text = text.strip('-')
    return text[:80]


def make_howto_step(text: str, name: Optional[str] = None, image: Optional[str] = None, url: Optional[str] = None) -> dict:
    text = html.fromstring(text).text_content().strip() if text else ''
    return {
        '@type': 'HowToStep',
        'name': name or None,
        'text': text,
        'image': image,
        'url': url,
    }


def split_step_text(text: str) -> List[str]:
    """Split instruction text on numbered lists and double line feeds."""
    if not text:
        return ['']

    text = re.sub(r'([.!?])(\d)', r'\1 \2', text)

    # Detect numbered-list patterns and split them apart.  We support:
    #   1. Step one 2. Step two
    #   Step 1: ... Step 2: ...
    #   1) ... 2) ...
    # as well as "(1) ... (2) ...".
    numbered_patterns = [
        r'(?:(?<=\s)|(?:^)|(?:"))(?:Step\s+)?\(?([0-9]+)\.\)\s+',
        r'(?:(?<=\s)|(?:^)|(?:"))(?:Step\s+)?([0-9]+)\.\s+(?=[A-Z0-9])',
        r'(?:(?<=\s)|(?:^)|(?:"))(?:Step\s+)?\(?([0-9]+)\)\s+(?=[A-Z0-9])',
        r'(?:(?<=\s)|(?:^)|(?:"))(?:Step\s+)?([0-9]+):\s+(?=[A-Z0-9])',
    ]
    for pattern in numbered_patterns:
        matches = list(re.finditer(pattern, ' ' + text + ' ', re.IGNORECASE))
        if len(matches) >= 2:
            split_points = [m.start() - 1 for m in matches[1:]]  # -1 because we padded a space
            parts = []
            prev = 0
            for point in split_points:
                chunk = text[prev:point].strip()
                if chunk:
                    chunk = re.sub(r'^(?:Step\s+)?\(?\d+[.):\)]?\)?\s*', '', chunk, flags=re.IGNORECASE).strip()
                    if chunk:
                        parts.append(chunk)
                prev = point
            tail = text[prev:].strip()
            tail = re.sub(r'^(?:Step\s+)?\(?\d+[.):\)]?\)?\s*', '', tail, flags=re.IGNORECASE).strip()
            if tail:
                parts.append(tail)
            if parts:
                return parts

    # Normalize different double-newline variants to a single delimiter.
    text = text.replace('\r\n\r\n', '\n\n').replace('\r\r', '\n\n')
    parts = [p.strip() for p in text.split('\n\n')]
    return [p for p in parts if p]


def normalize_instructions(instrs: List[Any], split_on_double_newline: bool = True, base_url: str = '') -> List[dict]:
    """Normalize a list of recipeInstructions into HowToStep objects."""
    steps = []
    for item in instrs:
        if isinstance(item, str):
            item_text = item.strip()
            if split_on_double_newline:
                for part in split_step_text(item_text):
                    steps.append(make_howto_step(part))
            else:
                steps.append(make_howto_step(item_text))
        elif isinstance(item, dict):
            atype = item.get('@type')
            if atype == 'HowToStep':
                name = item.get('name') or None
                text = item.get('text', '')
                image = extract_image_url(item.get('image'), base_url)
                url = item.get('url') or None
                if split_on_double_newline and isinstance(text, str):
                    parts = split_step_text(text)
                    for i, part in enumerate(parts):
                        steps.append(make_howto_step(part, name=name if i == 0 else None, image=image if i == 0 else None, url=url if i == 0 else None))
                else:
                    steps.append(make_howto_step(text, name=name, image=image, url=url))
            elif atype == 'HowToSection':
                section_name = item.get('name', '')
                for sub in item.get('itemListElement', []):
                    if isinstance(sub, dict) and sub.get('@type') == 'HowToStep':
                        name = sub.get('name') or None
                        text = sub.get('text', '')
                        image = extract_image_url(sub.get('image'), base_url)
                        url = sub.get('url') or None
                        if section_name and name:
                            name = f"{section_name}: {name}"
                        elif section_name:
                            name = section_name
                        if split_on_double_newline and isinstance(text, str):
                            parts = split_step_text(text)
                            for i, part in enumerate(parts):
                                steps.append(make_howto_step(part, name=name if i == 0 else None, image=image if i == 0 else None, url=url if i == 0 else None))
                        else:
                            steps.append(make_howto_step(text, name=name, image=image, url=url))
    return steps


def source_steps_have_image(instrs: List[Any]) -> bool:
    """Check whether any source JSON-LD instruction already carries an image."""
    for item in instrs:
        if isinstance(item, dict):
            if item.get('@type') == 'HowToStep' and extract_image_url(item.get('image')):
                return True
            if item.get('@type') == 'HowToSection':
                for sub in item.get('itemListElement', []):
                    if isinstance(sub, dict) and extract_image_url(sub.get('image')):
                        return True
    return False


def find_recipe_objects(data: Any, found: Optional[List[dict]] = None) -> List[dict]:
    if found is None:
        found = []
    if isinstance(data, dict):
        atype = data.get('@type')
        types = atype if isinstance(atype, list) else [atype]
        if 'Recipe' in types:
            found.append(data)
        for v in data.values():
            find_recipe_objects(v, found)
    elif isinstance(data, list):
        for item in data:
            find_recipe_objects(item, found)
    return found


def to_absolute_url(src: Optional[str], base_url: str) -> Optional[str]:
    """Convert a possibly relative image URL into an absolute URL."""
    if not src or not src.strip():
        return None
    src = src.strip()
    if src.startswith(('http://', 'https://')):
        return src
    if src.startswith('//'):
        return 'https:' + src
    if not base_url:
        return src
    return urljoin(base_url, src)


def extract_image_url(image: Any, base_url: str = '') -> Optional[str]:
    if isinstance(image, list):
        image = image[0] if image else None
    if isinstance(image, dict):
        image = image.get('url') or image.get('contentUrl')
    if isinstance(image, str) and image.strip():
        return to_absolute_url(image.strip(), base_url)
    return None


def normalize_author(author: Any, tree: Optional[html.HtmlElement] = None) -> Optional[dict]:
    """Normalize a JSON-LD author value, falling back to the page HTML if needed."""
    if isinstance(author, list):
        author = author[0] if author else None
    if isinstance(author, str) and author.strip():
        return {'@type': 'Person', 'name': author.strip(), 'url': None}
    if isinstance(author, dict):
        atype = author.get('@type', 'Person')
        if not atype:
            atype = 'Person'
        name = author.get('name')
        if name and str(name).strip():
            return {'@type': atype, 'name': name.strip() if isinstance(name, str) else name, 'url': author.get('url')}

    if tree is not None:
        html_author = extract_author_from_html(tree)
        if html_author:
            return html_author

    return None


def extract_author_from_html(tree: html.HtmlElement) -> Optional[dict]:
    """Try to extract an author name from common HTML markup patterns."""
    # Ordered selectors from most specific to least specific.
    selectors = [
        '//a[@rel="author" and @class="url fn"]',
        '//a[@rel="author"]',
        '//a[contains(@href, "/author/")]',
        '//span[@class="entry-author-name"]',
        '//span[@class="author vcard"]//a',
        '//span[@class="author vcard"]',
        '//span[@class="fn"]',
        '//p[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"author")]',
        '//div[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"author")]',
        '//span[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"author")]',
    ]
    ignore_words = {'by', 'posted', 'name', '*', 'says:', 'says'}
    for sel in selectors:
        for el in tree.xpath(sel):
            txt = ' '.join(el.itertext()).strip()
            if not txt:
                continue
            # strip common prefixes/suffixes
            clean = re.sub(r'(?i)\b(by|posted by|author|name)\b', ' ', txt)
            clean = re.sub(r'\s+', ' ', clean).strip()
            clean = clean.replace('says:', '').replace('says', '').strip()
            # remove stray leading colons left by some themes
            clean = re.sub(r'^:\s*', '', clean)
            clean = clean.strip()
            if clean and clean not in ignore_words and len(clean) > 1:
                # try to get URL from the element itself or its child link
                url = None
                if el.tag == 'a':
                    url = el.get('href')
                else:
                    for a in el.xpath('.//a'):
                        url = a.get('href')
                        if url:
                            break
                return {'@type': 'Person', 'name': clean, 'url': url}
    return None


def normalize_simple_list(value: Any) -> List[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(v) for v in value]
    return []


def has_value(v: Any) -> bool:
    if v is None:
        return False
    if isinstance(v, list):
        return any(has_value(x) for x in v)
    if isinstance(v, str):
        return bool(v.strip())
    if isinstance(v, dict):
        return any(has_value(x) for x in v.values())
    return True


def clean_text_list(items: List[str]) -> List[str]:
    cleaned = []
    seen = set()
    for item in items:
        if not isinstance(item, str):
            item = str(item)
        # strip label prefixes like "Category:", "Course:", "Cuisine:", "Keyword:"
        item = re.sub(r'(?i)^(category|course|cuisine|keyword|diet)\s*:?\s*', '', item)
        # strip "Course  Dinner" style labels (word + 2+ spaces)
        item = re.sub(r'(?i)^(category|course|cuisine|keyword|diet)\s+', '', item)
        # remove breadcrumb arrows and collapse whitespace, but keep slashes in URLs
        item = item.replace('›', ' ').replace('»', ' ').replace('|', ' ')
        item = re.sub(r'\s+', ' ', item).strip()
        if not item or len(item) > 60:
            continue
        low = item.lower()
        noise = {'home', 'recipe index', 'recipes', 'ingredients', 'occasions', 'articles', 'about',
                 'course', 'cuisine', 'category', 'keyword', 'diet', 'recipe tags', 'recipe',
                 'what to cook', 'staff picks', 'most popular', 'from our newsletters',
                 'about us', 'the new york times food section', 'the cooking newsletter',
                 'five weeknight dishes', 'the veggie bake time', 'reader favorites',
                 'easy baking', 'everyday recipes', 'quick', 'by meal', 'by diet',
                 'by method', 'by upcoming holiday', 'by occasion', 'how-tos',
                 'getting started', 'learn to cook', 'knife skills', 'scaling tips',
                 'video series', 'pizza', 'interview', 'print recipe', 'pin recipe',
                 'buy now', 'save recipe', 'email', 'please enable javascript',
                 'complete this form', 'says:', 'says', 'my recipes', 'sonia\'s favourite recipes',
                 'main', 'main dishes', 'one pot meals', 'one-pot meals'}
        if low in noise or low.startswith('says'):
            continue
        # skip CSS / JS fragments
        if '{' in item or '}' in item or 'javascript' in low:
            continue
        # skip items that look like recipe titles instead of tags
        words = low.split()
        if len(words) >= 4 and all(len(w) > 2 for w in words[:4]):
            # likely a recipe title like "street corn chicken power bowls" — skip
            continue
        if low in seen:
            continue
        seen.add(low)
        cleaned.append(item)
    return cleaned


def split_comma_separated(items: List[str]) -> List[str]:
    """Expand items that contain comma or newline separated values."""
    out = []
    for item in items:
        for part in re.split(r'[,;]|\n', item):
            part = part.strip()
            if part:
                out.append(part)
    return out


def merge_lists(jsonld_value: Any, html_value: List[str]) -> List[str]:
    base = normalize_simple_list(jsonld_value)
    combined = base + html_value
    return clean_text_list(split_comma_separated(combined))


# -----------------------------------------------------------------------------
# HTML fallback extractors for fields not populated in JSON-LD
# -----------------------------------------------------------------------------

META_SELECTORS = {
    'description': [
        'meta[@property="og:description"]/@content',
        'meta[@name="description"]/@content',
    ],
    'datePublished': [
        'meta[@property="article:published_time"]/@content',
        'meta[@name="datePublished"]/@content',
        'meta[@itemprop="datePublished"]/@content',
    ],
    'dateModified': [
        'meta[@property="article:modified_time"]/@content',
        'meta[@name="dateModified"]/@content',
        'meta[@itemprop="dateModified"]/@content',
    ],
}


def extract_meta_value(tree: html.HtmlElement, field: str) -> Optional[str]:
    for sel in META_SELECTORS.get(field, []):
        vals = tree.xpath(f'//{sel}')
        for v in vals:
            v = (v or '').strip()
            if v:
                return v
    return None


def extract_time_from_meta(tree: html.HtmlElement, field: str) -> Optional[str]:
    """Try to get a prep/cook/total time from meta or JSON-LD context."""
    # JSON-LD is the primary source; this is only used when JSON-LD is absent.
    return None


def parse_human_time(text: str) -> Optional[str]:
    """Convert strings like '15 mins', '1 hr 30 min' to ISO 8601 duration PT..."""
    if not text:
        return None
    text = text.strip().lower()
    # strip common labels
    text = re.sub(r'(?i)\b(prep time|cook time|total time|ready in|time)\s*:?\s*', '', text)
    text = re.sub(r'(?i)\b(serves?|yield|makes?)\b.*', '', text)
    text = text.strip()
    if not text:
        return None

    # already ISO 8601
    if text.startswith('pt') or text.startswith('p'):
        return text.upper() if re.match(r'^P\d', text.upper()) else text.upper()

    total_minutes = 0
    # patterns: 1 hr 30 min, 1 hour 30 minutes, 90 min, 1h30m, etc.
    hours = re.findall(r'(\d+(?:\.\d+)?)\s*(?:hr?s?|hours?)', text)
    mins = re.findall(r'(\d+(?:\.\d+)?)\s*(?:mins?|minutes?|m)\b', text)
    if not hours and not mins:
        # fallback: any number followed by h/m shorthand without space
        m = re.match(r'^(\d+(?:\.\d+)?)\s*h(?:rs?)?\s*(\d+(?:\.\d+)?)\s*m(?:ins?)?$', text)
        if m:
            hours, mins = [m.group(1)], [m.group(2)]
        else:
            m = re.match(r'^(\d+(?:\.\d+)?)\s*h(?:rs?)?$', text)
            if m:
                hours = [m.group(1)]
            else:
                m = re.match(r'^(\d+(?:\.\d+)?)\s*m(?:ins?)?$', text)
                if m:
                    mins = [m.group(1)]

    for h in hours:
        try:
            total_minutes += int(round(float(h) * 60))
        except ValueError:
            continue
    for m in mins:
        try:
            total_minutes += int(round(float(m)))
        except ValueError:
            continue

    if total_minutes > 0:
        if total_minutes < 60:
            return f'PT{total_minutes}M'
        h, m = divmod(total_minutes, 60)
        return f'PT{h}H{m}M' if m else f'PT{h}H'
    return None


def find_recipe_card(tree: html.HtmlElement) -> Optional[html.HtmlElement]:
    """Locate the recipe card / instructions container."""
    for candidate in tree.xpath(
        '//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"tasty-recipes") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-recipe") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"recipe") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"entry-content") '
        'or @itemtype="https://schema.org/Recipe"]'
    ):
        return candidate
    return None


def extract_text_near_label(tree: html.HtmlElement, labels: List[str]) -> Optional[str]:
    """Find text near a case-insensitive label like 'Prep Time:' in the recipe card."""
    card = find_recipe_card(tree)
    if card is None:
        card = tree
    label_pattern = '|'.join(re.escape(lbl) for lbl in labels)
    for el in card.iter():
        if not isinstance(el.tag, str):
            continue
        txt = ' '.join(el.itertext()).strip()
        if not txt:
            continue
        m = re.search(rf'(?i)(?:{label_pattern})\s*:?\s*([^\n\r]+)', txt)
        if m:
            return m.group(1).strip()
    return None


def extract_recipe_yield(tree: html.HtmlElement) -> List[str]:
    text = extract_text_near_label(tree, ['yield', 'serves', 'serving', 'makes'])
    if text:
        # Some pages list multiple yields, split on common separators.
        parts = re.split(r'[,;]|\band\b|\bor\b', text)
        return clean_text_list([p.strip() for p in parts if p.strip()])
    return []


def extract_recipe_time(tree: html.HtmlElement, field: str) -> Optional[str]:
    label_map = {
        'prepTime': ['prep time', 'preparation time', 'prep'],
        'cookTime': ['cook time', 'cooking time', 'cook'],
        'totalTime': ['total time', 'ready in', 'time'],
    }
    text = extract_text_near_label(tree, label_map.get(field, []))
    if text:
        iso = parse_human_time(text)
        if iso:
            return iso
    return None


def extract_html_tags(tree: html.HtmlElement, classes: List[str]) -> List[str]:
    """Extract tag text from common HTML tag/breadcrumb/category patterns."""
    results = []
    for cls in classes:
        for el in tree.xpath(
            f'//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"{cls}")]'
        ):
            txt = ' '.join(el.itertext()).strip()
            if txt:
                results.append(txt)
    return clean_text_list(results)


def extract_categories_from_html(tree: html.HtmlElement) -> List[str]:
    # Prefer explicit category links first, then recipe card category classes.
    results = []
    for sel in [
        '//a[contains(@href,"/category/")]',
        '//a[contains(@href,"/recipe-category/")]',
    ]:
        for el in tree.xpath(sel):
            txt = ' '.join(el.itertext()).strip()
            if txt and txt.lower() not in {'home', 'recipe', 'recipes'}:
                results.append(txt)
    if not results:
        # Look for WPRM-style recipe category classes on the recipe card only.
        for container in tree.xpath('//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-recipe")]'):
            for el in container.xpath(
                './/*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm_course-") '
                'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-recipe-course-")]'
            ):
                txt = ' '.join(el.itertext()).strip()
                if txt and txt.lower() not in {'course', 'course:'} and len(txt) < 40:
                    results.append(txt)
            break  # only use the first recipe container
    if not results:
        # Last resort: short breadcrumb links (skip mega navs).
        for el in tree.xpath('//nav[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"breadcrumb")]//a'):
            txt = ' '.join(el.itertext()).strip()
            if txt and txt.lower() not in {'home', 'recipe index', 'recipe', 'recipes'} and len(txt) < 40:
                results.append(txt)
    return clean_text_list(results)


def extract_cuisine_from_html(tree: html.HtmlElement) -> List[str]:
    results = []
    # Prefer explicit cuisine links first.
    for sel in [
        '//a[contains(@href,"/cuisine/")]',
        '//a[contains(@href,"/recipe-cuisine/")]',
    ]:
        for el in tree.xpath(sel):
            txt = ' '.join(el.itertext()).strip()
            if txt:
                results.append(txt)
    if not results:
        # Look for WPRM-style recipe cuisine classes on the recipe card only.
        for container in tree.xpath('//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-recipe")]'):
            for el in container.xpath(
                './/*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm_cuisine-") '
                'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-recipe-cuisine-")]'
            ):
                txt = ' '.join(el.itertext()).strip()
                if txt and txt.lower() not in {'cuisine', 'cuisine:'} and len(txt) < 40:
                    results.append(txt)
            break
    return clean_text_list(results)


def extract_keywords_from_html(tree: html.HtmlElement) -> List[str]:
    meta = extract_meta_value(tree, 'keywords')
    if meta:
        return [k.strip() for k in re.split(r'[,;]', meta) if k.strip()]
    results = []
    # Prefer explicit tag/keyword links.
    for sel in [
        '//a[contains(@href,"/tag/")]',
        '//a[contains(@href,"/keyword/")]',
        '//a[contains(@href,"/recipe-tag/")]',
    ]:
        for el in tree.xpath(sel):
            txt = ' '.join(el.itertext()).strip()
            if txt:
                results.append(txt)
    # WPRM ingredient/diet classes on the recipe card only.
    for container in tree.xpath('//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-recipe")]'):
        for el in container.xpath(
            './/*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-ingredient-") '
            'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"diet-type-")]'
        ):
            txt = ' '.join(el.itertext()).strip()
            if txt and txt.lower() not in {'ingredient', 'diet type'} and len(txt) < 40:
                results.append(txt)
        break
    return clean_text_list(results)


def extract_description_from_html(tree: html.HtmlElement) -> Optional[str]:
    desc = extract_meta_value(tree, 'description')
    if desc:
        return desc
    # Some pages put a recipe summary in a schema-ish paragraph.
    return None


def extract_dates_from_html(tree: html.HtmlElement, field: str) -> Optional[str]:
    # Try meta first.
    meta = extract_meta_value(tree, field)
    if meta:
        return meta
    # Try <time> elements.
    for sel in ['//time[@datetime]/@datetime', '//time/@datetime']:
        for v in tree.xpath(sel):
            v = (v or '').strip()
            if v:
                return v
    return None


def merge_lists(jsonld_value: Any, html_value: List[str]) -> List[str]:
    base = normalize_simple_list(jsonld_value)
    combined = base + html_value
    return clean_text_list(combined)


def normalize_recipe_field(
    recipe: dict,
    tree: Optional[html.HtmlElement],
    field: str,
    html_extractor,
    default: Any,
    use_jsonld_first: bool = True,
):
    """Return JSON-LD value if present, else HTML fallback, else default."""
    if use_jsonld_first:
        if has_value(recipe.get(field)):
            return recipe.get(field)
    if tree is not None:
        fallback = html_extractor(tree)
        if has_value(fallback):
            return fallback
    return default


def normalize_date(value: Any) -> Optional[str]:
    if not value:
        return None
    if isinstance(value, list):
        value = value[0] if value else None
    if not isinstance(value, str):
        value = str(value)
    value = value.strip()
    if not value:
        return None
    # If already ISO-ish, leave it; otherwise keep original string.
    return value


def normalize_times(value: Any) -> Optional[str]:
    if not value:
        return None
    if isinstance(value, list):
        value = value[0] if value else None
    if not isinstance(value, str):
        value = str(value)
    value = value.strip()
    if not value:
        return None
    # Try to clean/normalize ISO 8601 durations.
    if value.upper().startswith('PT'):
        v = value.upper()
        # Collapse repeated zeros and invalid order where possible.
        v = re.sub(r'PT0+[HMS]', '', v)
        return v if len(v) > 2 else None
    if value.upper().startswith('P'):
        return value.upper()
    # Try to parse human-readable times.
    iso = parse_human_time(value)
    if iso:
        return iso
    return value


def normalize_yield(value: Any) -> List[str]:
    if not value:
        return []
    if isinstance(value, str):
        parts = re.split(r'[,;]|\band\b|\bor\b', value)
        return clean_text_list([p.strip() for p in parts if p.strip()])
    if isinstance(value, list):
        return clean_text_list([str(v) for v in value])
    return []


def normalize_suitable_for_diet(value: Any) -> List[str]:
    items = normalize_simple_list(value)
    cleaned = []
    for item in items:
        item = item.strip()
        if not item:
            continue
        # Accept well-formed schema.org diet URIs.
        if item.startswith('https://schema.org/'):
            cleaned.append(item)
            continue
        # Fix strings where clean_text_list stripped slashes, e.g. "https: schema.org GlutenFreeDiet"
        m = re.match(r'https\s*:\s*schema\.org\s+(.+)', item, re.I)
        if m:
            tail = m.group(1).replace(' ', '')
            cleaned.append(f'https://schema.org/{tail}')
            continue
        # Fix strings where only the slash after https was removed: "https: //schema.org/..."
        if re.match(r'https\s*:\s*/+schema\.org/', item, re.I):
            cleaned.append(re.sub(r'\s+', '', item))
            continue
        low = item.lower()
        mapping = {
            'vegan': 'https://schema.org/VeganDiet',
            'vegetarian': 'https://schema.org/VegetarianDiet',
            'gluten-free': 'https://schema.org/GlutenFreeDiet',
            'gluten free': 'https://schema.org/GlutenFreeDiet',
            'low calorie': 'https://schema.org/LowCalorieDiet',
            'low fat': 'https://schema.org/LowFatDiet',
            'low lactose': 'https://schema.org/LowLactoseDiet',
            'low salt': 'https://schema.org/LowSaltDiet',
            'diabetic': 'https://schema.org/DiabeticDiet',
            'halal': 'https://schema.org/HalalDiet',
            'kosher': 'https://schema.org/KosherDiet',
        }
        if low in mapping:
            cleaned.append(mapping[low])
        # otherwise drop unrecognized strings to keep output clean
    return clean_text_list(cleaned)


def map_step_images_from_html(tree: html.HtmlElement, steps: List[dict], base_url: str = '') -> None:
    """Fallback per-step image mapping from page HTML.

    Heuristic: locate the recipe card/instructions container, then for each step
    find the smallest HTML element containing the step text. Look for an <img>
    inside that element; if none, look at the closest preceding and following
    sibling elements within the same container. Only accept image URLs that look
    like actual images (exclude data URIs, SVGs, and tiny avatars).
    """
    if not steps:
        return

    def is_usable_image(src: str) -> bool:
        if not src or not src.strip():
            return False
        src = src.strip()
        if src.startswith('data:'):
            return False
        if 'gravatar.com/avatar' in src:
            return False
        if src.endswith(('.svg', '.gif')):
            return False
        if src.startswith(('http://', 'https://', '/')):
            return True
        return False

    # Locate the recipe card / instructions container.
    container = None
    for candidate in tree.xpath(
        '//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"tasty-recipes") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"wprm-recipe") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"recipe") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"entry-content") '
        'or @itemtype="https://schema.org/Recipe"]'
    ):
        container = candidate
        break
    if container is None:
        container = tree

    # Collect all usable images in document order with their element.
    all_imgs = []
    for img in tree.iter('img'):
        src = img.get('src') or img.get('data-src') or img.get('data-lazy-src')
        if is_usable_image(src):
            all_imgs.append((img, to_absolute_url(src.strip(), base_url)))

    # Try to locate the recipe instructions container.
    containers = []
    for candidate in tree.xpath(
        '//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"instruction") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"method") '
        'or contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"steps")]'
    ):
        containers.append(candidate)

    for i, step in enumerate(steps):
        step_text = step.get('text', '')
        if not step_text:
            continue

        matched_img = None

        # Find the most specific element inside the container that contains this step text.
        best_el = None
        best_len = float('inf')
        for el in container.iter():
            if not isinstance(el.tag, str):
                continue
            if el.tag in ('script', 'style', 'noscript'):
                continue
            el_text = ' '.join(el.itertext()).strip()
            if not el_text:
                continue
            if step_text in el_text and len(el_text) < best_len:
                best_el = el
                best_len = len(el_text)

        if best_el is None:
            continue

        # 1. Image inside the matched element.
        for img, src in all_imgs:
            if img is best_el or img in best_el.iterdescendants():
                matched_img = src
                break

        # 2. Sibling images near the matched element.
        if not matched_img:
            parent = best_el.getparent()
            if parent is not None and isinstance(parent.tag, str):
                siblings = list(parent)
                if best_el in siblings:
                    idx = siblings.index(best_el)
                    # check a few following siblings and one preceding sibling
                    for offset in (1, 2, 3, -1):
                        sib_idx = idx + offset
                        if 0 <= sib_idx < len(siblings):
                            sib = siblings[sib_idx]
                            if not isinstance(sib.tag, str):
                                continue
                            for img, src in all_imgs:
                                if img is sib or img in sib.iterdescendants():
                                    matched_img = src
                                    break
                        if matched_img:
                            break

        # 3. Fallback: assign images to steps in document order, but only if they
        # appear after the recipe container starts and before the next step's text.
        if not matched_img and all_imgs:
            # use the i-th image that appears after the matched element
            following_for_step = [
                src for img, src in all_imgs
                if best_el.getparent() is None or img in best_el.xpath('./following::img')
            ]
            if i < len(following_for_step):
                matched_img = following_for_step[i]
            elif i < len(all_imgs):
                matched_img = all_imgs[i][1]

        if matched_img:
            step['image'] = matched_img


def build_recipe_dict(
    recipe: dict,
    url: str,
    ingredients: List[dict],
    instructions: List[dict],
    identifier: Optional[str] = None,
    tree: Optional[html.HtmlElement] = None,
) -> dict:
    """Build the canonical recipe object from extracted parts."""
    if identifier is None:
        domain = url.split('/')[2].lower()
        if domain.startswith('www.'):
            domain = domain[4:]
        slug = slugify(recipe.get('name', ''))
        identifier = f"{domain}:{slug}"

    rid = str(uuid.uuid5(KITCHENMIX_NAMESPACE, identifier))
    image = extract_image_url(recipe.get('image'), url)
    author = normalize_author(recipe.get('author'), tree=tree)

    tree_present = tree is not None

    date_published = normalize_date(recipe.get('datePublished'))
    if not date_published and tree_present:
        date_published = normalize_date(extract_dates_from_html(tree, 'datePublished'))

    date_modified = normalize_date(recipe.get('dateModified'))
    if not date_modified and tree_present:
        date_modified = normalize_date(extract_dates_from_html(tree, 'dateModified'))

    description = (recipe.get('description') or '').strip()
    if not description and tree_present:
        description = (extract_description_from_html(tree) or '').strip()
    if not description:
        description = None

    prep_time = normalize_times(recipe.get('prepTime'))
    if not prep_time and tree_present:
        prep_time = extract_recipe_time(tree, 'prepTime')

    cook_time = normalize_times(recipe.get('cookTime'))
    if not cook_time and tree_present:
        cook_time = extract_recipe_time(tree, 'cookTime')

    total_time = normalize_times(recipe.get('totalTime'))
    if not total_time and tree_present:
        total_time = extract_recipe_time(tree, 'totalTime')

    recipe_yield = normalize_yield(recipe.get('recipeYield'))
    if not recipe_yield and tree_present:
        recipe_yield = extract_recipe_yield(tree)

    recipe_category = merge_lists(recipe.get('recipeCategory'), extract_categories_from_html(tree) if tree_present else [])
    recipe_cuisine = merge_lists(recipe.get('recipeCuisine'), extract_cuisine_from_html(tree) if tree_present else [])
    keywords = merge_lists(recipe.get('keywords'), extract_keywords_from_html(tree) if tree_present else [])
    suitable_for_diet = normalize_suitable_for_diet(recipe.get('suitableForDiet'))

    # Ensure every step image is an absolute URL.
    for step in instructions:
        if isinstance(step, dict) and step.get('image'):
            step['image'] = to_absolute_url(step['image'], url)

    result = {
        '@context': 'https://schema.org',
        '@type': 'Recipe',
        'id': rid,
        'identifier': identifier,
        'name': recipe.get('name'),
        'url': url,
        'image': image,
        'recipeCategory': recipe_category,
        'recipeIngredient': ingredients,
        'recipeInstructions': instructions,
        'author': author,
        'datePublished': date_published,
        'dateModified': date_modified,
        'description': description,
        'prepTime': prep_time,
        'cookTime': cook_time,
        'totalTime': total_time,
        'recipeYield': recipe_yield,
        'recipeCuisine': recipe_cuisine,
        'keywords': keywords,
        'nutrition': recipe.get('nutrition') if has_value(recipe.get('nutrition')) else None,
        'aggregateRating': recipe.get('aggregateRating') if has_value(recipe.get('aggregateRating')) else None,
        'suitableForDiet': suitable_for_diet,
        'video': recipe.get('video') if has_value(recipe.get('video')) else None,
        '@id': recipe.get('@id') or None,
    }
    return result
