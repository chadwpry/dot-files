---
name: recipe-jsonld
description: >
  Extract a complete, canonical JSON-LD recipe object from any public recipe URL
  that uses Schema.org JSON-LD markup. Use when the user shares a recipe URL that
  is not covered by a domain-specific `recipe-*` skill (e.g. not theguardian.com or
  thedoctorskitchen.com). Emits the same output shape as every other `recipe-*`
  skill. This skill also provides the shared `recipe_common.py` utility module used
  by the other `recipe-*` skills for parsing, normalization, and HTML fallback
  helpers.
---

# recipe-jsonld

Extract a canonical, Schema.org-compatible recipe from any public recipe URL that
serves JSON-LD recipe markup. This skill provides the shared `recipe_common.py`
module; other `recipe-*` skills import and reuse it.

## Shared module

`recipe_common.py` lives next to this SKILL.md. The other recipe skills add the
recipe-jsonld directory to `sys.path` and import helper functions from it:

```python
import sys
sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import (
    fetch_with_retries,
    find_recipe_objects,
    parse_ingredient,
    normalize_instructions,
    build_recipe_dict,
    ...
)
```

Keep `recipe_common.py` backwards-compatible for all dependent skills.

## When to use this skill

Use this skill when the user:

- Shares a recipe URL with Schema.org `application/ld+json` markup.
- Wants to extract, parse, convert, or save a recipe from that URL.
- Wants ingredient amounts, units, and method steps in a structured format.
- The URL is **not** from a domain that has its own `recipe-*` skill.

If the URL is from `theguardian.com`, use `recipe-theguardian-com` instead.  
If the URL is from `thedoctorskitchen.com`, use `recipe-thedoctorskitchen-com` instead.

## Output shape

Before extracting, read [references/recipe-output-schema.md](references/recipe-output-schema.md)
and follow it exactly. Every `recipe-*` skill must produce the same canonical
shape.

Key requirements:
- Emit `@context`, `@type`, `id`, `identifier`, `name`, `url`, `image`,
  `recipeCategory`, `recipeIngredient`, and `recipeInstructions`.
- Generate `id` as a UUIDv5 from `identifier` using the KitchenMix namespace
  `3c6e7b7e-df8d-4bda-8b5c-5e7b9d2f3a1c`.
- Set `identifier` to `<domain>:<recipe-slug>`.
- Make `image` required and non-empty. If no image is found, fail extraction.
- Include all optional fields with `null` / `[]` / `{}` defaults when unavailable.

## Extraction workflow

1. **GET the recipe page** using the agent's HTTP tool. Retry transient failures
   (network errors, 5xx, 429, or intermittent 403s) up to 3 times with
   exponential backoff before giving up.
2. **Parse all `<script type="application/ld+json">` blocks.** JSON-LD may be
   wrapped in `@graph`, arrays, or nested objects.
3. **Locate the `Recipe` object.** Most pages contain exactly one. If multiple
   `Recipe` objects are present, choose the one whose `name` best matches the page
   title/heading. If you cannot confidently choose, ask the user which recipe to
   extract.
4. **Extract top-level recipe fields:** `name`, `description`, `image`,
   `datePublished`, `prepTime`, `cookTime`, `totalTime`, `recipeYield`,
   `recipeCategory`, `recipeCuisine`, `keywords`, `author`, `nutrition`,
   `aggregateRating`, `suitableForDiet`, `video`.
   - For `author`, use the JSON-LD `author` value when present. If it is missing,
     null, or empty, fall back to common HTML author markup (e.g.
     `<a rel="author">`, `<span class="author">`, `<a href="/author/...">`,
     `<span class="entry-author-name">`). Strip leading words such as "By"
     and "Posted by". If no author can be found, set `author` to `null`.
5. **Normalize `recipeIngredient`.** Each raw ingredient string should be split
   into `{name, quantity, unit, note}`.
   - `quantity` must be a float/real number. Convert unicode fractions (½, ¼,
     ¾, etc.), common mojibake fraction sequences (e.g. `Â¼`, `Â½`, `Â¾`), and
     spelled-out slash fractions (`1/2`, `1/4`, `1/8`, `3/4`, etc.) to decimals.
     Word fractions such as `half`, `quarter`, `third` should also become
     decimals. Mixed numbers (`1 ½`, `1 1/2`) should be summed to a single
     float. Ranges (`1-2`, `1 to 2`) should be reduced to a single float (use
     the midpoint, or the first number when a midpoint cannot be computed).
   - `unit` must be one of the KitchenMix approved units only:
     `bag`, `bunch`, `head`, `loaf`, `package`, `piece`,
     `ml`, `l`, `tsp`, `tbsp`, `c`, `fl-oz`, `pt`, `qt`, `gal`,
     `mg`, `g`, `kg`, `oz`, `lb`. Normalize common synonyms and plurals to the
     canonical value (e.g. `cup`/`cups` → `c`, `tablespoon`/`tablespoons` → `tbsp`,
     `pound`/`pounds` → `lb`). If no recognized unit is present, leave it empty.
   - Preserve parenthetical notes in `note`.
   - If parsing fails, store the full string as `name`, set `quantity` to `null`,
     and leave `unit` and `note` empty.
6. **Normalize `recipeInstructions`.** Convert plain strings to `HowToStep` objects.
   Flatten `HowToSection` hierarchies.
   - **Step splitting:** if a single source instruction text contains a double
     line feed (`\n\n`) or a numbered list such as `1. ... 2. ...`, split it
     into multiple `HowToStep` objects using `\n\n` and numbered markers as
     separators.
   - **Per-step images:** inspect the source JSON-LD instructions. If at least
     one step already has an `image`, keep all step images as-is and do not add
     fallback images. If *none* of the JSON-LD steps have an `image`, attempt
     to map nearby images from the page HTML to each step. If no image can be
     confidently matched, leave the step `image` as `null`.
7. **Determine the `identifier`.**
   - Domain = hostname lowercased. If it starts with the literal prefix `www.`,
     remove exactly that prefix (do not strip individual characters).
   - Slug = slugified recipe `name`.
   - `identifier = "{domain}:{slug}"`.
8. **Generate `id`** as `uuid.uuid5(KITCHENMIX_NAMESPACE, identifier)`.
9. **Write the recipe to disk.** Ensure `./recipes` exists, then save as
   `./recipes/{domain}-{slug}.json` with pretty-printed JSON.
10. **Return the saved file path and a summary** to the user.

## Important notes

- Some sites block automated requests (e.g. 403). Do not bypass protections;
  report the URL as unsupported.
- If the page has no `application/ld+json` block, no `Recipe` object, or no
  `image`, extraction should fail and the user should be told why.
- Keep ingredient `quantity` and `unit` as faithful to the source text as
  possible. Do not convert units unless explicitly requested.
