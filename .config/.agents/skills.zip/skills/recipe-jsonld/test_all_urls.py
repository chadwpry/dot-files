#!/usr/bin/env python3
"""Run all recipe-* skill extraction logic against every URL in existing-urls.csv."""
import csv
import json
import re
import sys
from pathlib import Path
from lxml import html

sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import (
    find_recipe_objects,
    source_steps_have_image,
    normalize_instructions,
    parse_ingredient,
    extract_image_url,
    build_recipe_dict,
    map_step_images_from_html,
    fetch_with_retries,
    slugify,
    to_absolute_url,
)

HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; KitchenMixBot/1.0)'}
OUT_DIR = Path('./recipes')
OUT_DIR.mkdir(parents=True, exist_ok=True)
SUMMARY_FILE = OUT_DIR / 'extraction-summary.json'


def find_heading_ids(tree):
    headings = {}
    for h in tree.xpath('//h2 | //h3 | //h4'):
        text = ' '.join(h.itertext()).strip()
        hid = h.get('id')
        if text and hid:
            headings[hid] = text
    return headings


def map_guardian_step_images(tree, steps, recipe, base_url=''):
    if not steps:
        return
    body = tree.xpath('//article') or [tree]
    container = body[0]
    elements = [el for el in container.iter() if el.tag in ('figure', 'p')]

    def img_src(el):
        img = el.find('.//img') if el.tag == 'figure' else None
        if img is not None:
            src = img.get('src') or img.get('data-src')
            if src and src.strip():
                return src.strip()
        return None

    prev_idx = -1
    for i, step in enumerate(steps):
        step_text = step.get('text', '')
        if not step_text:
            continue

        # find matching paragraph
        best_p_idx = None
        best_score = 0
        for idx, el in enumerate(elements):
            if el.tag != 'p':
                continue
            el_text = ' '.join(el.itertext()).strip()
            if not el_text:
                continue
            if step_text in el_text or el_text in step_text:
                best_p_idx = idx
                best_score = float('inf')
                break
            words = set(step_text.lower().split())
            el_words = set(el_text.lower().split())
            score = len(words & el_words)
            if score > best_score:
                best_score = score
                best_p_idx = idx

        if best_p_idx is None:
            continue

        # closest figure between previous and current paragraph
        chosen = None
        for idx in range(prev_idx + 1, best_p_idx):
            el = elements[idx]
            if el.tag == 'figure':
                src = img_src(el)
                if src:
                    chosen = src
        if not chosen:
            for idx in range(best_p_idx - 1, prev_idx, -1):
                el = elements[idx]
                if el.tag == 'figure':
                    src = img_src(el)
                    if src:
                        chosen = src
                        break

        if chosen:
            step['image'] = to_absolute_url(chosen, base_url)

        prev_idx = best_p_idx


def extract_generic(url):
    r = fetch_with_retries('GET', url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    tree = html.fromstring(r.content)

    recipes = []
    for s in tree.xpath('//script[@type="application/ld+json"]'):
        text = (s.text or '').strip()
        if not text:
            continue
        try:
            data = json.loads(text)
        except Exception:
            continue
        recipes.extend(find_recipe_objects(data))
    if not recipes:
        raise ValueError('No Recipe object found')

    if len(recipes) > 1:
        title = ' '.join(tree.xpath('//title/text()'))
        best = None
        best_score = -1
        for rec in recipes:
            name = rec.get('name', '')
            score = sum(1 for w in name.lower().split() if w in title.lower())
            if score > best_score:
                best_score = score
                best = rec
        recipe = best
    else:
        recipe = recipes[0]

    domain = url.split('/')[2].lower()
    if domain.startswith('www.'):
        domain = domain[4:]
    slug = slugify(recipe.get('name', ''))
    identifier = f"{domain}:{slug}"

    image = extract_image_url(recipe.get('image'), url)
    if not image:
        raise ValueError('No recipe image found')

    ingredients = [parse_ingredient(i) for i in recipe.get('recipeIngredient', [])]
    raw_instructions = recipe.get('recipeInstructions', [])
    has_ld_images = source_steps_have_image(raw_instructions)
    instructions = normalize_instructions(raw_instructions, split_on_double_newline=True, base_url=url)
    if not has_ld_images:
        map_step_images_from_html(tree, instructions, base_url=url)

    result = build_recipe_dict(recipe, url, ingredients, instructions, identifier, tree=tree)
    return result


def extract_guardian(url):
    r = fetch_with_retries('GET', url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    tree = html.fromstring(r.content)

    recipes = []
    for s in tree.xpath('//script[@type="application/ld+json"]'):
        text = (s.text or '').strip()
        if not text:
            continue
        try:
            data = json.loads(text)
        except Exception:
            continue
        recipes.extend(find_recipe_objects(data))
    if not recipes:
        raise ValueError('No Recipe object found')

    headings = find_heading_ids(tree)
    heading_by_name = {v: k for k, v in headings.items()}

    results = []
    for recipe in recipes:
        recipe_name = recipe.get('name', '')
        heading_id = heading_by_name.get(recipe_name)
        slug = heading_id or slugify(recipe_name)
        identifier = f"theguardian.com:{slug}"

        image = extract_image_url(recipe.get('image'), url)
        if not image:
            continue

        ingredients = [parse_ingredient(i) for i in recipe.get('recipeIngredient', [])]
        raw_instructions = recipe.get('recipeInstructions', [])
        has_ld_images = source_steps_have_image(raw_instructions)
        instructions = normalize_instructions(raw_instructions, split_on_double_newline=True, base_url=url)
        if not has_ld_images:
            map_guardian_step_images(tree, instructions, recipe, base_url=url)

        result = build_recipe_dict(recipe, url, ingredients, instructions, identifier, tree=tree)
        results.append(result)
    return results


def find_tdk_recipe(data):
    if isinstance(data, dict):
        atype = data.get('@type')
        types = atype if isinstance(atype, list) else [atype]
        if 'Recipe' in types:
            return data
        for v in data.values():
            res = find_tdk_recipe(v)
            if res:
                return res
    elif isinstance(data, list):
        for item in data:
            res = find_tdk_recipe(item)
            if res:
                return res
    return None


def extract_thedoctorskitchen(url):
    r = fetch_with_retries('GET', url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    tree = html.fromstring(r.content)

    recipe = None
    for s in tree.xpath('//script[@type="application/ld+json"]'):
        text = (s.text or '').strip()
        if not text:
            continue
        try:
            data = json.loads(text)
        except Exception:
            continue
        recipe = find_tdk_recipe(data)
        if recipe:
            break
    if not recipe:
        raise ValueError('No Recipe object found')

    recipe_id = None
    for inp in tree.xpath('//input[@name="recipe_id"]/@value'):
        recipe_id = inp
        break
    if not recipe_id:
        for st in tree.xpath('//script/text()'):
            m = re.search(r'let\s+page_object_id\s*=\s*"([^"]+)"', st)
            if m:
                recipe_id = m.group(1)
                break
    if not recipe_id:
        raise ValueError('Could not find recipe_id')

    quantities = {}
    try:
        resp = fetch_with_retries(
            'POST',
            'https://www.thedoctorskitchen.com/ajax/recipe_quantities.php',
            headers={**HEADERS, 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
            data=f'recipe_id={recipe_id}&new_portions=1&unit_cmd=',
            timeout=20,
        )
        if resp.status_code == 200:
            qdata = resp.json()
            for item in qdata.get('data', {}).get('for_page', []):
                iid = str(item.get('ingredient_group_item_id'))
                quantities[iid] = item
    except Exception as e:
        print(f'  WARN: quantity endpoint failed: {e}')

    ingredients = []
    for row in tree.xpath('//*[@data-ingredient-group-item-id]'):
        iid = row.get('data-ingredient-group-item-id')
        name_el = row.xpath('.//*[@data-ingredient-name]')
        name = name_el[0].text_content().strip() if name_el else row.text_content().strip()
        note_els = row.xpath('.//small[contains(@class,"text-grey")]')
        note = note_els[0].text_content().strip() if note_els else ''

        q = quantities.get(iid, {})
        amount = q.get('amount', '')
        unit = q.get('unit', '')

        combined = f"{amount} {unit} {name}".strip()
        parsed = parse_ingredient(combined)
        if note:
            parsed['note'] = note if not parsed.get('note') else f"{parsed['note']}; {note}"
        ingredients.append(parsed)

    html_steps = []
    for n in range(1, 200):
        el = tree.xpath(f'//div[@id="instruction_step_{n}"]')
        if not el:
            break
        text = ' '.join(el[0].itertext()).strip()
        text = re.sub(r'^\s*\d+\s*', '', text).strip()
        if text:
            html_steps.append({'@type': 'HowToStep', 'text': text})

    raw_instructions = recipe.get('recipeInstructions', [])
    has_ld_images = source_steps_have_image(raw_instructions)

    if html_steps:
        instructions = normalize_instructions(html_steps, split_on_double_newline=True, base_url=url)
    else:
        instructions = normalize_instructions(raw_instructions, split_on_double_newline=True, base_url=url)

    if not has_ld_images:
        for i, step in enumerate(instructions):
            n = i + 1
            div = tree.xpath(f'//div[@id="instruction_step_{n}"]')
            if div:
                img = div[0].find('.//img')
                if img is not None:
                    src = img.get('src') or img.get('data-src')
                    if src and src.strip():
                        step['image'] = to_absolute_url(src.strip(), url)
                        continue
            for img in tree.iter('img'):
                alt = (img.get('alt') or '').lower()
                if 'step' in alt or 'method' in alt:
                    src = img.get('src') or img.get('data-src')
                    if src and src.strip():
                        step['image'] = to_absolute_url(src.strip(), url)
                        break

    domain = 'thedoctorskitchen.com'
    slug = slugify(recipe.get('name', ''))
    identifier = f"{domain}:{slug}"

    image = extract_image_url(recipe.get('image'), url)
    if not image:
        raise ValueError('No recipe image found')

    result = build_recipe_dict(recipe, url, ingredients, instructions, identifier, tree=tree)
    return [result]


def validate_output(data):
    """Lightweight validation checks."""
    errors = []
    required = ['@context', '@type', 'id', 'identifier', 'name', 'url', 'image', 'recipeCategory', 'recipeIngredient', 'recipeInstructions']
    for f in required:
        if f not in data:
            errors.append(f'missing {f}')
    if not data.get('image'):
        errors.append('empty image')
    if not isinstance(data.get('recipeIngredient'), list):
        errors.append('recipeIngredient not list')
    if not isinstance(data.get('recipeInstructions'), list):
        errors.append('recipeInstructions not list')
    for ing in data.get('recipeIngredient', []):
        if 'unit' not in ing or 'quantity' not in ing or 'name' not in ing or 'note' not in ing:
            errors.append('ingredient missing field')
        if ing.get('quantity') is not None and not isinstance(ing.get('quantity'), (int, float)):
            errors.append(f'quantity not number: {ing.get("quantity")}')
    for step in data.get('recipeInstructions', []):
        if step.get('@type') != 'HowToStep':
            errors.append('instruction not HowToStep')
        if 'text' not in step or 'image' not in step or 'url' not in step or 'name' not in step:
            errors.append('instruction missing field')
    return errors


if __name__ == '__main__':
    csv_path = './recipes/existing-urls.csv'
    rows = list(csv.DictReader(open(csv_path, newline='', encoding='utf-8')))

    summary = {
        'total_urls': len(rows),
        'jsonld_urls': 0,
        'successful': 0,
        'failed': 0,
        'validation_errors': 0,
        'recipes_generated': 0,
        'domains': {},
        'failures': [],
        'identifiers': [],
    }

    for row in rows:
        if row['has_jsonld'] != 'true':
            continue
        summary['jsonld_urls'] += 1
        url = row['url']
        domain = url.split('/')[2].lower()
        if domain.startswith('www.'):
            domain = domain[4:]
        summary['domains'][domain] = summary['domains'].get(domain, 0) + 1

        try:
            if domain == 'theguardian.com':
                results = extract_guardian(url)
            elif domain == 'thedoctorskitchen.com':
                results = extract_thedoctorskitchen(url)
            else:
                results = [extract_generic(url)]

            for data in results:
                summary['recipes_generated'] += 1
                summary['identifiers'].append(data.get('identifier'))
                errors = validate_output(data)
                if errors:
                    summary['validation_errors'] += 1
                    summary['failures'].append({'url': url, 'name': data.get('name'), 'errors': errors})
                else:
                    summary['successful'] += 1

                fname = data['identifier'].replace(':', '-') + '.json'
                out_path = OUT_DIR / fname
                with open(out_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            summary['failed'] += 1
            summary['failures'].append({'url': url, 'name': None, 'errors': [str(e)]})

    summary_path = SUMMARY_FILE
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"\n=== Full run summary ===")
    print(f"Total JSON-LD URLs: {summary['jsonld_urls']}")
    print(f"Recipes generated: {summary['recipes_generated']}")
    print(f"Successful (validation clean): {summary['successful']}")
    print(f"Failed extraction: {summary['failed']}")
    print(f"Validation errors: {summary['validation_errors']}")
    print(f"Domains: {len(summary['domains'])}")
    print(f"Summary saved: {summary_path}")
    print(f"\nFirst 10 failures:")
    for fail in summary['failures'][:10]:
        print(f"  - {fail['url']}: {fail.get('name')} | {fail['errors']}")
