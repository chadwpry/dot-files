#!/usr/bin/env python3
"""Test generic recipe-jsonld extraction with updated parsing rules."""
import csv
import json
import re
from pathlib import Path
from lxml import html

import sys
sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import (
    find_recipe_objects,
    source_steps_have_image,
    normalize_instructions,
    parse_ingredient,
    extract_image_url,
    build_recipe_dict,
    map_step_images_from_html,
    fetch_with_retries,
    slugify,
)

HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; KitchenMixBot/1.0)'}


def extract(url):
    r = fetch_with_retries('GET', url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    tree = html.fromstring(r.content)

    recipes = []
    for s in tree.xpath('//script[@type="application/ld+json"]'):
        text = (s.text or '').strip()
        if not text:
            continue
        try:
            data = json.loads(text)
        except Exception:
            continue
        recipes.extend(find_recipe_objects(data))
    if not recipes:
        raise ValueError('No Recipe object found')

    if len(recipes) > 1:
        title = ' '.join(tree.xpath('//title/text()'))
        best = None
        best_score = -1
        for rec in recipes:
            name = rec.get('name', '')
            score = sum(1 for w in name.lower().split() if w in title.lower())
            if score > best_score:
                best_score = score
                best = rec
        recipe = best
    else:
        recipe = recipes[0]

    domain = url.split('/')[2].lower()
    if domain.startswith('www.'):
        domain = domain[4:]
    slug = slugify(recipe.get('name', ''))
    identifier = f"{domain}:{slug}"

    image = extract_image_url(recipe.get('image'), url)
    if not image:
        raise ValueError('No recipe image found')

    # Ingredients
    raw_ingredients = recipe.get('recipeIngredient', [])
    ingredients = [parse_ingredient(i) for i in raw_ingredients]

    # Instructions
    raw_instructions = recipe.get('recipeInstructions', [])
    has_ld_images = source_steps_have_image(raw_instructions)
    instructions = normalize_instructions(raw_instructions, split_on_double_newline=True, base_url=url)
    if not has_ld_images:
        map_step_images_from_html(tree, instructions, base_url=url)

    result = build_recipe_dict(recipe, url, ingredients, instructions, identifier, tree=tree)

    Path('./recipes').mkdir(exist_ok=True)
    out_path = f'./recipes/{domain}-{slug}.json'
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    return result, out_path


if __name__ == '__main__':
    test_urls = [
        'https://cookieandkate.com/cabbage-vegetable-soup/',
        'https://cooking.nytimes.com/recipes/1013041-turkey-and-hominy-chili-with-smoky-chipotle?unlocked_article_code=1.FFA.hQJ0.pG29tnbQmeie&smid=ck-recipe-iOS-share',
        'https://www.kingarthurbaking.com/recipes/chocolate-chip-oatmeal-cookies-recipe',
        'https://kalejunkie.com/20-minute-dumpling-skillet',
        'https://pinchofyum.com/chicken-tacos',
        'https://www.recipetineats.com/borek-turkish-spiced-lamb-filo-pastry/#h-how-to-make-borek',
        'https://www.halfbakedharvest.com/chicken-katsu-noodle-bowls/',
    ]
    for url in test_urls:
        print(f'\n=== {url} ===')
        try:
            data, path = extract(url)
            print(f'  id: {data["id"]}')
            print(f'  identifier: {data["identifier"]}')
            print(f'  name: {data["name"]}')
            print(f'  image: {data["image"][:80]}...')
            print(f'  ingredients: {len(data["recipeIngredient"])}')
            print(f'  instructions: {len(data["recipeInstructions"])}')
            print(f'  steps with images: {sum(1 for s in data["recipeInstructions"] if s.get("image"))}')
            print(f'  saved: {path}')
            print(f'  sample ingredient: {data["recipeIngredient"][0]}')
            if data['recipeInstructions']:
                print(f'  sample instruction: {data["recipeInstructions"][0]}')
        except Exception as e:
            print(f'  ERROR: {e}')
