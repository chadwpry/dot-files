#!/usr/bin/env python3
"""Test recipe-thedoctorskitchen-com extraction with updated parsing rules."""
import json
import re
from pathlib import Path
from lxml import html

import sys
sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import (
    find_recipe_objects,
    normalize_instructions,
    parse_ingredient,
    extract_image_url,
    build_recipe_dict,
    source_steps_have_image,
    fetch_with_retries,
    slugify,
    to_absolute_url,
)

HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; KitchenMixBot/1.0)'}


def extract(url):
    r = fetch_with_retries('GET', url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    tree = html.fromstring(r.content)

    def find_recipe(data):
        if isinstance(data, dict):
            atype = data.get('@type')
            types = atype if isinstance(atype, list) else [atype]
            if 'Recipe' in types:
                return data
            for v in data.values():
                res = find_recipe(v)
                if res:
                    return res
        elif isinstance(data, list):
            for item in data:
                res = find_recipe(item)
                if res:
                    return res
        return None

    recipe = None
    for s in tree.xpath('//script[@type="application/ld+json"]'):
        text = (s.text or '').strip()
        if not text:
            continue
        try:
            data = json.loads(text)
        except Exception:
            continue
        recipe = find_recipe(data)
        if recipe:
            break
    if not recipe:
        raise ValueError('No Recipe object found')

    # find recipe_id
    recipe_id = None
    for inp in tree.xpath('//input[@name="recipe_id"]/@value'):
        recipe_id = inp
        break
    if not recipe_id:
        for st in tree.xpath('//script/text()'):
            m = re.search(r'let\s+page_object_id\s*=\s*"([^"]+)"', st)
            if m:
                recipe_id = m.group(1)
                break
    if not recipe_id:
        raise ValueError('Could not find recipe_id')

    # fetch quantities
    quantities = {}
    try:
        resp = fetch_with_retries(
            'POST',
            'https://www.thedoctorskitchen.com/ajax/recipe_quantities.php',
            headers={**HEADERS, 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
            data=f'recipe_id={recipe_id}&new_portions=1&unit_cmd=',
            timeout=20,
        )
        if resp.status_code == 200:
            qdata = resp.json()
            for item in qdata.get('data', {}).get('for_page', []):
                iid = str(item.get('ingredient_group_item_id'))
                quantities[iid] = item
    except Exception as e:
        print(f'  WARN: quantity endpoint failed: {e}')

    # parse ingredient rows
    ingredients = []
    for row in tree.xpath('//*[@data-ingredient-group-item-id]'):
        iid = row.get('data-ingredient-group-item-id')
        name_el = row.xpath('.//*[@data-ingredient-name]')
        name = name_el[0].text_content().strip() if name_el else row.text_content().strip()
        note_els = row.xpath('.//small[contains(@class,"text-grey")]')
        note = note_els[0].text_content().strip() if note_els else ''

        q = quantities.get(iid, {})
        amount = q.get('amount', '')
        unit = q.get('unit', '')

        # Parse the combined amount+unit+name string so that fractions/units are normalized.
        combined = f"{amount} {unit} {name}".strip()
        parsed = parse_ingredient(combined)
        if note:
            parsed['note'] = note if not parsed.get('note') else f"{parsed['note']}; {note}"
        ingredients.append(parsed)

    # instructions: prefer HTML instruction_step_N divs
    html_steps = []
    for n in range(1, 200):
        el = tree.xpath(f'//div[@id="instruction_step_{n}"]')
        if not el:
            break
        text = ' '.join(el[0].itertext()).strip()
        text = re.sub(r'^\s*\d+\s*', '', text).strip()
        if text:
            html_steps.append({'@type': 'HowToStep', 'text': text})

    raw_instructions = recipe.get('recipeInstructions', [])
    has_ld_images = source_steps_have_image(raw_instructions)

    if html_steps:
        instructions = normalize_instructions(html_steps, split_on_double_newline=True, base_url=url)
    else:
        instructions = normalize_instructions(raw_instructions, split_on_double_newline=True, base_url=url)

    # Map step images from HTML only when JSON-LD provides no step images.
    if not has_ld_images:
        for i, step in enumerate(instructions):
            step_text = step.get('text', '')
            n = i + 1
            div = tree.xpath(f'//div[@id="instruction_step_{n}"]')
            if div:
                img = div[0].find('.//img')
                if img is not None:
                    src = img.get('src') or img.get('data-src')
                    if src and src.strip():
                        step['image'] = to_absolute_url(src.strip(), url)
                        continue
            # fallback: search nearby images in page
            for img in tree.iter('img'):
                alt = (img.get('alt') or '').lower()
                if 'step' in alt or 'method' in alt:
                    src = img.get('src') or img.get('data-src')
                    if src and src.strip():
                        step['image'] = to_absolute_url(src.strip(), url)
                        break

    domain = 'thedoctorskitchen.com'
    slug = slugify(recipe.get('name', ''))
    identifier = f"{domain}:{slug}"

    image = extract_image_url(recipe.get('image'), url)
    if not image:
        raise ValueError('No recipe image found')

    result = build_recipe_dict(recipe, url, ingredients, instructions, identifier, tree=tree)

    Path('./recipes').mkdir(exist_ok=True)
    out_path = f'./recipes/{domain}-{slug}.json'
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    return result, out_path


if __name__ == '__main__':
    url = 'https://www.thedoctorskitchen.com/recipes/oat-and-flax-wraps'
    print(f"=== TheDoctor's Kitchen: {url} ===")
    try:
        data, path = extract(url)
        print(f'  id: {data["id"]}')
        print(f'  identifier: {data["identifier"]}')
        print(f'  name: {data["name"]}')
        print(f'  image: {data["image"][:80]}...')
        print(f'  ingredients: {len(data["recipeIngredient"])}')
        print(f'  instructions: {len(data["recipeInstructions"])}')
        print(f'  steps with images: {sum(1 for s in data["recipeInstructions"] if s.get("image"))}')
        print(f'  saved: {path}')
        print(f'  sample ingredient: {data["recipeIngredient"][0]}')
        if data['recipeInstructions']:
            print(f'  sample instruction: {data["recipeInstructions"][0]}')
    except Exception as e:
        print(f'  ERROR: {e}')
