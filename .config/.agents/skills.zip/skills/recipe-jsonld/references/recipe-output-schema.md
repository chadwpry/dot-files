# Canonical Recipe Output Schema

All `recipe-*` skills produce the same JSON-LD `Recipe` object shape. This document defines the required and optional fields and their normalization rules.

The output is designed to be consumed by the KitchenMix application and saved to disk as `./recipes/<domain>-<recipe-slug>.json`.

## Deterministic identifier

Every recipe must have a stable, deterministic identifier.

1. Derive `identifier` from the recipe source:
   - Format: `<domain>:<recipe-slug>`
   - `<domain>` is the recipe page hostname lowercased, with the literal
     leading prefix `www.` removed (remove the exact string `www.`, not
     individual characters).
   - `<recipe-slug>` is derived from the recipe `name`: lowercase, collapse sequences of non-alphanumeric characters to a single hyphen, trim leading/trailing hyphens, and keep it to 80 characters max.
2. Generate `id` as a UUIDv5 from `identifier` using the fixed KitchenMix namespace:
   - `3c6e7b7e-df8d-4bda-8b5c-5e7b9d2f3a1c`
3. Emit both `id` and `identifier` in the output.

This guarantees:
- The same recipe always produces the same `id`.
- Recipes with the same name on different domains never collide.
- Multiple recipes on one page (e.g. The Guardian) each get a distinct identifier.

## Required fields

| Field | Type | Description |
|-------|------|-------------|
| `@context` | string | Always `"https://schema.org"`. |
| `@type` | string | Always `"Recipe"`. |
| `id` | string | UUIDv5 generated from `identifier`. |
| `identifier` | string | `<domain>:<recipe-slug>`. |
| `name` | string | Recipe title. |
| `url` | string | Canonical source URL. |
| `image` | string | Main recipe image URL. Must be non-empty. If no image can be found, extraction should fail and the caller should decide whether to proceed. |
| `recipeIngredient` | array | List of ingredient objects (see below). |
| `recipeInstructions` | array | List of `HowToStep` objects (see below). |
| `recipeCategory` | array of strings | Categories such as course, meal type, or dish type. Required, may be empty. |

## Ingredient object

Each ingredient must be normalized to:

```json
{
  "name": "string",
  "quantity": 1.5,
  "unit": "string",
  "note": "string"
}
```

Rules:
- `name`: the ingredient name, cleaned of parenthetical notes and quantity/unit prefixes.
- `quantity`: numeric amount as a float/real number.
  - Unicode fractions (½, ¼, ¾, etc.) are converted to decimals, including
    common mojibake sequences (`Â¼`, `Â½`, `Â¾`, etc.) produced when UTF-8 bytes
    are decoded as Latin-1.
  - Spelled-out slash fractions (1/2, 1/4, 1/8, 3/4, etc.) are converted to decimals.
  - Word fractions (`half`, `quarter`, `third`, etc.) are converted to decimals.
  - Mixed numbers (`1 ½`, `1 1/2`) are summed into a single float.
  - Ranges (`1-2`, `1 to 2`) are reduced to a single float (use the midpoint, or the first number when a midpoint cannot be computed).
- `unit`: unit of measure from the KitchenMix approved unit list only:
  `bag`, `bunch`, `head`, `loaf`, `package`, `piece`,
  `ml`, `l`, `tsp`, `tbsp`, `c`, `fl-oz`, `pt`, `qt`, `gal`,
  `mg`, `g`, `kg`, `oz`, `lb`.
  Common synonyms and plurals may be normalized to their canonical value
  (e.g. `cup`/`cups` → `c`, `tablespoon`/`tablespoons` → `tbsp`,
  `pound`/`pounds` → `lb`). If no recognized unit is present, leave it empty.
- `note`: parenthetical text, preparation hints, swap suggestions, or anything not part of the core name. Empty if none.

If an ingredient string cannot be parsed reliably, preserve the full text as `name`, set `quantity` to `null`, and leave `unit` and `note` empty.

## Instruction object

Each instruction must be normalized to a Schema.org `HowToStep`:

```json
{
  "@type": "HowToStep",
  "name": "string|null",
  "text": "string",
  "image": "string|null",
  "url": "string|null"
}
```

Rules:
- `text`: the full step text, HTML-entities decoded, normalized whitespace.
- `name`: the step name if the source provides one (e.g. Tasty-style "Brown the chicken"), otherwise `null`.
- `image`: optional per-step image URL if one can be confidently matched, otherwise `null`.
- `url`: optional anchor/permalink for the step if the source provides one, otherwise `null`.
- **Step splitting:** if a single source instruction contains a double line
  feed (`\n\n`) or a numbered list such as `1. ... 2. ...`, split it into
  multiple `HowToStep` objects. Use `\n\n` and numbered markers as separators.
  This captures sites that emit one JSON-LD step containing several numbered
  paragraphs.

If the source provides `HowToSection` objects, flatten them into a single `recipeInstructions` array. Preserve section names by prepending them to each step's `name` or `text` where appropriate.

## Optional fields (always present, null/empty when unavailable)

| Field | Type | Default |
|-------|------|---------|
| `author` | `{ "@type": "Person|Organization", "name": "string", "url": "string|null" }` | `null` |
| `datePublished` | string (ISO 8601 or original published date string) | `null` |
| `dateModified` | string (ISO 8601 or original modified date string) | `null` |
| `description` | string | `null` |
| `prepTime` | string (ISO 8601 duration) | `null` |
| `cookTime` | string (ISO 8601 duration) | `null` |
| `totalTime` | string (ISO 8601 duration) | `null` |
| `recipeYield` | array of strings | `[]` |
| `recipeCuisine` | array of strings | `[]` |
| `keywords` | array of strings | `[]` |
| `nutrition` | `{ "@type": "NutritionInformation", ... }` | `null` |
| `aggregateRating` | `{ "@type": "AggregateRating", ... }` | `null` |
| `suitableForDiet` | array of strings | `[]` |
| `video` | `{ "@type": "VideoObject", ... }` | `null` |
| `@id` | string | `null` |

*Note: `recipeType` was removed from the canonical schema. It is no longer emitted.*

## Full example object

```json
{
  "@context": "https://schema.org",
  "@type": "Recipe",
  "id": "3c6e7b7e-...",
  "identifier": "theguardian.com:spicy-coconut-dal",
  "name": "Spicy coconut dal",
  "url": "https://www.theguardian.com/food/2026/may/13/south-asian-coconut-dal-cheesy-pickle-toasties-carrot-halva-recipes-cakes-ravinder-bhogal",
  "image": "https://media.guim.co.uk/.../2063.jpg",
  "author": {
    "@type": "Person",
    "name": "Ravinder Bhogal",
    "url": null
  },
  "datePublished": "2026-05-13",
  "dateModified": null,
  "description": "...",
  "prepTime": "PT10M",
  "cookTime": "PT25M",
  "totalTime": "PT35M",
  "recipeYield": ["4"],
  "recipeCategory": ["Main course"],
  "recipeCuisine": ["Indian"],
  "keywords": ["dal", "coconut", "vegan"],
  "recipeIngredient": [
    {
      "name": "red lentils",
      "quantity": 200.0,
      "unit": "g",
      "note": "rinsed"
    }
  ],
  "recipeInstructions": [
    {
      "@type": "HowToStep",
      "name": null,
      "text": "Rinse the lentils...",
      "image": null,
      "url": null
    }
  ],
  "nutrition": null,
  "aggregateRating": null,
  "suitableForDiet": ["https://schema.org/VeganDiet"],
  "video": null,
  "@id": null
}
```

## File output

- Create `./recipes` if it does not exist.
- Serialize with `json.dumps(..., indent=2, ensure_ascii=False)`.
- Save to `./recipes/<domain>-<recipe-slug>.json`.
- Report the saved path to the user.

## Special cases

- **No JSON-LD**: mark as unsupported and do not fabricate data.
- **No image**: extraction should fail or warn; do not silently add the recipe.
- **Multiple recipes on one page**: skill-specific logic must disambiguate (e.g. The Guardian uses HTML heading anchors and recipe names).
- **Locked/missing data**: skill-specific logic may fetch additional endpoints (e.g. The Doctor's Kitchen quantity AJAX endpoint) and merge results.
