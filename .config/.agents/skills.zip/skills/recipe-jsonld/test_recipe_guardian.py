#!/usr/bin/env python3
"""Test recipe-theguardian-com extraction with updated parsing rules."""
import json
import re
from pathlib import Path
from lxml import html

import sys
sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import (
    find_recipe_objects,
    normalize_instructions,
    parse_ingredient,
    extract_image_url,
    build_recipe_dict,
    source_steps_have_image,
    fetch_with_retries,
    slugify,
    to_absolute_url,
)

HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; KitchenMixBot/1.0)'}


def find_heading_ids(tree):
    headings = {}
    for h in tree.xpath('//h2 | //h3 | //h4'):
        text = ' '.join(h.itertext()).strip()
        hid = h.get('id')
        if text and hid:
            headings[hid] = text
    return headings


def map_guardian_step_images(tree, steps, recipe, base_url=''):
    """Guardian-specific image mapping from article HTML."""
    if not steps:
        return

    # Gather article body elements in order, limited to figures and paragraphs.
    body = tree.xpath('//article') or [tree]
    container = body[0]
    elements = []
    for el in container.iter():
        if el.tag in ('figure', 'p'):
            elements.append(el)

    # Find preceding image for each step's paragraph match.
    for i, step in enumerate(steps):
        step_text = step.get('text', '')
        if not step_text:
            continue

        best_p = None
        best_score = 0
        for el in elements:
            if el.tag != 'p':
                continue
            el_text = ' '.join(el.itertext()).strip()
            if not el_text:
                continue
            if step_text in el_text or el_text in step_text:
                best_p = el
                break
            # word overlap fallback
            words = set(step_text.lower().split())
            el_words = set(el_text.lower().split())
            score = len(words & el_words)
            if score > best_score:
                best_score = score
                best_p = el

        if best_p is None:
            continue

        # Find the closest preceding figure image after the previous step's paragraph.
        prev_index = -1
        if i > 0:
            for prev_el in elements:
                if prev_el.tag == 'p' and prev_el is best_p:
                    break
                prev_index = elements.index(prev_el) if prev_el in elements else -1

        chosen = None
        for el in elements:
            idx = elements.index(el)
            if el.tag != 'figure':
                continue
            if idx <= prev_index:
                continue
            if idx > elements.index(best_p):
                continue
            img = el.find('.//img')
            if img is not None:
                src = img.get('src') or img.get('data-src')
                if src and src.strip():
                    chosen = src.strip()
                    break

        if not chosen:
            # fallback to closest preceding figure anywhere
            for el in reversed(elements[:elements.index(best_p)]):
                if el.tag == 'figure':
                    img = el.find('.//img')
                    if img is not None:
                        src = img.get('src') or img.get('data-src')
                        if src and src.strip():
                            chosen = src.strip()
                            break

        if chosen:
            step['image'] = to_absolute_url(chosen, base_url)


def extract(url, target_name=None):
    r = fetch_with_retries('GET', url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    tree = html.fromstring(r.content)

    recipes = []
    for s in tree.xpath('//script[@type="application/ld+json"]'):
        text = (s.text or '').strip()
        if not text:
            continue
        try:
            data = json.loads(text)
        except Exception:
            continue
        recipes.extend(find_recipe_objects(data))
    if not recipes:
        raise ValueError('No Recipe object found')

    headings = find_heading_ids(tree)
    heading_by_name = {v: k for k, v in headings.items()}

    if target_name:
        recipe = None
        for rec in recipes:
            if rec.get('name') == target_name or target_name in rec.get('name', ''):
                recipe = rec
                break
        if recipe is None:
            recipe = recipes[0]
    else:
        recipe = recipes[0]

    recipe_name = recipe.get('name', '')
    heading_id = heading_by_name.get(recipe_name)
    slug = heading_id or slugify(recipe_name)
    identifier = f"theguardian.com:{slug}"

    image = extract_image_url(recipe.get('image'), url)
    if not image:
        raise ValueError('No recipe image found')

    ingredients = [parse_ingredient(i) for i in recipe.get('recipeIngredient', [])]

    raw_instructions = recipe.get('recipeInstructions', [])
    has_ld_images = source_steps_have_image(raw_instructions)
    instructions = normalize_instructions(raw_instructions, split_on_double_newline=True, base_url=url)
    if not has_ld_images:
        map_guardian_step_images(tree, instructions, recipe, base_url=url)

    result = build_recipe_dict(recipe, url, ingredients, instructions, identifier, tree=tree)

    Path('./recipes').mkdir(exist_ok=True)
    out_path = f'./recipes/theguardian.com-{slug}.json'
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    return result, out_path, len(recipes)


if __name__ == '__main__':
    test_cases = [
        ('https://www.theguardian.com/food/2025/aug/30/barbecue-tempeh-rice-bowl-with-lime-sriracha-sauce-recipe-meera-sodha', 'Barbecue tempeh rice bowl with lime and sriracha'),
        ('https://www.theguardian.com/food/2026/may/13/south-asian-coconut-dal-cheesy-pickle-toasties-carrot-halva-recipes-cakes-ravinder-bhogal', 'Spicy coconut dal'),
        ('https://www.theguardian.com/food/2026/may/13/south-asian-coconut-dal-cheesy-pickle-toasties-carrot-halva-recipes-cakes-ravinder-bhogal', 'Goan aubergine pickle, cheddar and chutney toasted sandwich'),
        ('https://www.theguardian.com/food/article/2024/may/23/lime-prawns-and-beetroot-salad-yotam-ottolenghi-recipes-for-the-bank-holiday', 'Beetroot pkhali with marinated beetroot and olive salsa'),
        ('https://www.theguardian.com/food/article/2024/may/23/lime-prawns-and-beetroot-salad-yotam-ottolenghi-recipes-for-the-bank-holiday', 'Grilled lime prawns and courgettes'),
    ]
    for url, target_name in test_cases:
        print(f'\n=== {target_name} ===')
        print(f'URL: {url}')
        try:
            data, path, count = extract(url, target_name)
            print(f'  page recipes found: {count}')
            print(f'  id: {data["id"]}')
            print(f'  identifier: {data["identifier"]}')
            print(f'  name: {data["name"]}')
            print(f'  image: {data["image"][:80]}...')
            print(f'  ingredients: {len(data["recipeIngredient"])}')
            print(f'  instructions: {len(data["recipeInstructions"])}')
            print(f'  steps with images: {sum(1 for s in data["recipeInstructions"] if s.get("image"))}')
            print(f'  saved: {path}')
            print(f'  sample ingredient: {data["recipeIngredient"][0]}')
            if data['recipeInstructions']:
                print(f'  sample instruction: {data["recipeInstructions"][0]}')
        except Exception as e:
            print(f'  ERROR: {e}')
