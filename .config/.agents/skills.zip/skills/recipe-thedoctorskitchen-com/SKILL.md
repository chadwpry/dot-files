---
name: recipe-thedoctorskitchen-com
description: >
  Extract a complete JSON-LD recipe (including ingredient amounts and units) from
  any public TheDoctor's Kitchen URL (https://www.thedoctorskitchen.com). Use
  when the user shares a thedoctorskitchen.com recipe link and wants the full
  recipe in a structured, machine-readable format. Emits the same canonical recipe
  object as every other `recipe-*` skill. Reuses the shared
  `recipe-jsonld/recipe_common.py` module for parsing, normalization, and output
  building; adds a domain-specific AJAX quantity lookup where needed.
---

# recipe-thedoctorskitchen-com

Extract a complete, canonical recipe from a public TheDoctor's Kitchen recipe URL.
This skill reuses the shared helpers in `recipe_common.py` from the
`recipe-jsonld` skill. At runtime add the recipe-jsonld directory to `sys.path`:

```python
import sys
sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import (
    fetch_with_retries,
    find_recipe_objects,
    parse_ingredient,
    normalize_instructions,
    build_recipe_dict,
    source_steps_have_image,
    ...
)
```

## When to use this skill

Use this skill when the user:

- Shares a URL from `thedoctorskitchen.com`, especially under `/recipes/`.
- Asks to extract, parse, convert, or save a recipe from that site.
- Wants ingredient amounts, units, and method steps.

## Output shape

Before extracting, read `recipe-jsonld/references/recipe-output-schema.md` and
follow it exactly. The Doctor's Kitchen skill must produce the same canonical
shape as every other `recipe-*` skill.

## Extraction workflow

1. **GET the recipe page** using the agent's HTTP tool. Retry transient failures
   (network errors, 5xx, 429, or intermittent 403s) up to 3 times with
   exponential backoff before giving up.
2. **Parse the HTML** to find:
   - the `<script type="application/ld+json">` block;
   - the internal `recipe_id` (`let page_object_id = "…"` or the hidden
     `<input name="recipe_id">`);
   - every ingredient row, identified by `data-ingredient-group-item-id`,
     with its name and any small grey note (e.g. swaps, prep hints).
3. **POST to the hidden endpoint** to retrieve the locked quantities. Retry
   transient failures up to 3 times with exponential backoff:
   ```
   POST https://www.thedoctorskitchen.com/ajax/recipe_quantities.php
   Content-Type: application/x-www-form-urlencoded

   recipe_id=<id>&new_portions=1&unit_cmd=
   ```
4. **Merge** the ingredient rows from the HTML with the amounts/units from
   the JSON response, keyed by `ingredient_group_item_id`.
5. **Normalize ingredients** to `{name, quantity, unit, note}` objects.
   - `quantity` must be a float/real number. Convert unicode fractions (½, ¼,
     ¾, etc.), common mojibake sequences (`Â¼`, `Â½`, `Â¾`, etc.), and spelled-out
     slash fractions (`1/2`, `1/4`, `1/8`, `3/4`, etc.) to decimals. Word
     fractions such as `half`, `quarter`, `third` should also become decimals. If
     no unit is present, treat the amount as a count.
   - `unit` must be one of the KitchenMix approved units only:
     `bag`, `bunch`, `head`, `loaf`, `package`, `piece`,
     `ml`, `l`, `tsp`, `tbsp`, `c`, `fl-oz`, `pt`, `qt`, `gal`,
     `mg`, `g`, `kg`, `oz`, `lb`. Normalize common synonyms and plurals to the
     canonical value. If no recognized unit is present, leave it empty.
   - Preserve notes such as preparation hints and swap suggestions. If an
     ingredient string cannot be parsed reliably, preserve the full text as
     `name`, set `quantity` to `null`, and leave `unit` and `note` empty.
6. **Normalize instructions** to `HowToStep` objects. The primary source is the
   HTML `instruction_step_N` divs; fall back to JSON-LD `HowToStep` objects if
   those divs are not present.
   - **Step splitting:** if a single source instruction text contains a double
     line feed (`\n\n`) or a numbered list such as `1. ... 2. ...`, split it
     into multiple `HowToStep` objects using `\n\n` and numbered markers as
     separators.
   - **Per-step images:** inspect the source JSON-LD instructions. If at least
     one step already has an `image`, keep all step images as-is. If *none* have
     an image, look at the surrounding HTML for each step (`<div id="instruction_step_N">`
     or nearby `<img>` tags) and add the closest matching image URL to each step.
     If no image can be confidently matched, leave the step `image` as `null`.
7. **Extract top-level fields** from the JSON-LD and HTML: `name`, `author`,
   `datePublished`, `description`, `image`, `totalTime`, `recipeYield`,
   `recipeCategory`, `recipeCuisine`, `keywords`, `nutrition`, etc. Fill optional
   fields with `null` / `[]` defaults when unavailable.
   - For `author`, use the JSON-LD `author` value when present. If it is missing,
     null, or empty, fall back to common HTML author markup (e.g.
     `<a rel="author">`, `<span class="author">`, `<a href="/author/...">`,
     `<span class="entry-author-name">`). Strip leading words such as "By"
     and "Posted by". If no author can be found, set `author` to `null`.
8. **Compute the `identifier`.**
   - Domain = `thedoctorskitchen.com`.
   - Slug = slugified recipe `name`.
   - `identifier = "thedoctorskitchen.com:{slug}"`.
9. **Generate `id`** as `uuid.uuid5(KITCHENMIX_NAMESPACE, identifier)` using the
   KitchenMix namespace `3c6e7b7e-df8d-4bda-8b5c-5e7b9d2f3a1c`.
10. **Write the extracted recipe to disk:**
    - Ensure `./recipes` exists.
    - Save as `./recipes/thedoctorskitchen.com-{slug}.json` with pretty-printed UTF-8 JSON.
    - Include the saved file path in the response.

## Important notes

- The quantity endpoint does not require authentication for public pages
  tested, but may return empty values if the site changes access controls.
- `unit_cmd` should be left empty unless the user explicitly asks for a unit
  conversion such as `set_metric_pref` or `set_imperial_pref`.
- If an ingredient has no unit, treat the amount as a count.
- Preserve notes such as preparation hints and swap suggestions.
- `image` is required. If the page provides no recipe image, fail extraction
  and report the issue.
