---
name: recipe-theguardian-com
description: >
  Extract a complete JSON-LD recipe (including ingredient amounts and units)
  from any public The Guardian food/recipe URL
  (https://www.theguardian.com/food/...). Use when the user shares a
  theguardian.com food article link and wants the full recipe in a
  structured, machine-readable format. Handles articles that contain multiple
  recipes per page and emits the same canonical recipe object as every other
  `recipe-*` skill. Reuses the shared `recipe-jsonld/recipe_common.py` module
  for parsing, normalization, image matching, and output building.
---

# recipe-theguardian-com

Extract a complete, canonical recipe from a public The Guardian food article URL.
This skill reuses the shared helpers in `recipe_common.py` from the
`recipe-jsonld` skill. At runtime add the recipe-jsonld directory to `sys.path`:

```python
import sys
sys.path.insert(0, '/home/obsv/.pi/agent/skills/recipe-jsonld')
from recipe_common import (
    fetch_with_retries,
    find_recipe_objects,
    parse_ingredient,
    normalize_instructions,
    build_recipe_dict,
    source_steps_have_image,
    ...
)
```

## When to use this skill

Use this skill when the user:

- Shares a URL from `theguardian.com`, especially under `/food/`.
- Asks to extract, parse, convert, or save a recipe from that site.
- Wants ingredient amounts, units, and method steps.

## Output shape

Before extracting, read `recipe-jsonld/references/recipe-output-schema.md` and
follow it exactly. The Guardian skill must produce the same canonical shape as
every other `recipe-*` skill.

## Extraction workflow

1. **GET the article page** using the agent's HTTP tool. Retry transient failures
   (network errors, 5xx, 429, or intermittent 403s) up to 3 times with
   exponential backoff before giving up.
2. **Parse the HTML** to find every `<script type="application/ld+json">` block.
   The Guardian embeds recipes inside a top-level array or `@graph`, alongside
   `NewsArticle` and `WebPage` objects.
3. **Select the correct `Recipe` object.** Guardian articles often contain
   **multiple recipes** on one page. Disambiguate by matching the recipe `name`
   from the JSON-LD to the closest `<h2>` heading in the article body. The heading
   `id` is a URL slug derived from the recipe name, e.g.:
   ```html
   <h2 id="spicy-coconut-dal">Spicy coconut dal</h2>
   ```
   If no matching heading is found, use the recipe `name` directly. If you still
   cannot choose confidently, ask the user which recipe to extract.
4. **Compute the `identifier`.**
   - Domain = `theguardian.com`.
   - Slug = the HTML heading `id` if available, otherwise slugified recipe `name`.
   - `identifier = "theguardian.com:{slug}"`.
5. **Generate `id`** as `uuid.uuid5(KITCHENMIX_NAMESPACE, identifier)` using the
   KitchenMix namespace `3c6e7b7e-df8d-4bda-8b5c-5e7b9d2f3a1c`.
6. **Parse each `recipeIngredient` string** into `{name, quantity, unit, note}`.
   Guardian ingredient strings combine quantity, optional unit, and name in a
   single line, e.g.:
   - `1 large red onion` → `{name: "large red onion", quantity: 1, unit: ""}`
   - `100g plain, thick wholemilk yoghurt` → `{name: "plain, thick wholemilk yoghurt", quantity: 100, unit: "g"}`
   - `5tbsp fresh mint leaves (10g)` → `{name: "fresh mint leaves", quantity: 5, unit: "tbsp", note: "10g"}`

   Rules:
   - `quantity` must be a float/real number. Replace Unicode fractions (½, ¼,
     ¾, etc.), common mojibake sequences (`Â¼`, `Â½`, `Â¾`, etc.), and spelled-out
     slash fractions (`1/2`, `1/4`, `1/8`, `3/4`, etc.) with decimal equivalents.
     Word fractions such as `half`, `quarter`, `third` should also become
     decimals. Mixed numbers (`1 ½`, `1 1/2`) should be summed to a single float.
     Ranges (`1-2`, `1 to 2`) should be reduced to a single float (use the
     midpoint, or the first number when a midpoint cannot be computed).
   - `unit` must be one of the KitchenMix approved units only:
     `bag`, `bunch`, `head`, `loaf`, `package`, `piece`,
     `ml`, `l`, `tsp`, `tbsp`, `c`, `fl-oz`, `pt`, `qt`, `gal`,
     `mg`, `g`, `kg`, `oz`, `lb`. Normalize common synonyms and plurals to the
     canonical value. If no recognized unit is present, leave it empty.
   - First match a leading number/decimal/range followed by an attached unit
     (no space), e.g. `100g`, `1.5tsp`, `2tbsp`.
   - If no attached unit, match a leading number/decimal/range followed by the
     ingredient name, e.g. `1 large red onion`, `6 black peppercorns`.
   - Treat parenthetical text as a `note`, e.g. `(10g)`. Inline and trailing
     parentheses are both extracted.
   - If the string has no leading quantity, leave `quantity` as `null` and `unit`
     empty and store the full string as `name` (e.g. `Fine sea salt`).
7. **Normalize `recipeInstructions`.**
   - Keep Guardian JSON-LD steps as `HowToStep` objects with `@type`, `text`, and
     usually an empty `image` array.
   - **Step splitting:** if a single source instruction text contains a double
     line feed (`\n\n`) or a numbered list such as `1. ... 2. ...`, split it
     into multiple `HowToStep` objects using `\n\n` and numbered markers as
     separators.
   - **Per-step images:** inspect the source JSON-LD instructions. If at least
     one step already has an `image`, keep all step images as-is. If *none* have
     an image, run the Guardian HTML image-mapping heuristic below.
8. **Enhance method steps with per-step images from the article HTML (only when JSON-LD provides no step images):**
   - Extract the ordered list of top-level elements from the article body,
     keeping `<figure>` and `<p>` elements in document order.
   - For each `HowToStep` from the JSON-LD, find the `<p>` element whose text best
     matches the step text (use word-overlap scoring and a leading-phrase bonus).
   - Assign the closest preceding `<figure>` image to that step, restricted to
     images that appear after the previous step's matching paragraph and before
     the current step's matching paragraph. If no image exists in that window,
     fall back to the closest preceding image in the whole article.
   - Keep the original Guardian image URL exactly as it appears in the HTML,
     including its query-string parameters (width, dpr, signing token). Do not
     strip the query string, or the image will return 401 Unauthorized.
   - If no image can be matched, leave the step without an `image` property.
9. **Fill all other canonical fields** (`author`, `datePublished`, `description`,
   `image`, `totalTime`, `prepTime`, `cookTime`, `recipeYield`, `recipeCategory`,
   `recipeCuisine`, `suitableForDiet`, etc.) with values from the JSON-LD. Use
   `null` / `[]` defaults for missing optional fields.
   - For `author`, use the JSON-LD `author` value when present. If it is missing,
     null, or empty, fall back to common HTML author markup (e.g.
     `<a rel="author">`, `<span class="author">`, `<a href="/author/...">`,
     `<span class="entry-author-name">`). Strip leading words such as "By"
     and "Posted by". If no author can be found, set `author` to `null`.
10. **Write the extracted recipe to disk:**
    - Ensure `./recipes` exists.
    - Save as `./recipes/theguardian.com-{slug}.json` with pretty-printed UTF-8 JSON.
    - Include the saved file path in the response.

## Important notes

- Guardian recipe pages tested are public and do not require authentication,
  but access controls may change.
- Ingredient parsing is heuristic. If a string cannot be parsed reliably,
  preserve the original text as `name` and leave `quantity`/`unit` empty.
- Method-step image mapping is heuristic and depends on the article's HTML
  layout. Some steps may share the same image when Guardian groups multiple
  steps under a single paragraph/figure.
- Preserve notes such as parenthetical weights or preparation hints.
